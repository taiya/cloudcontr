function [M, joints, segments] = remove_small_cycles(M, joints, segments, threshold, show_cycles)
% removing small cycles measured by topological length <= threshold
G = M.skel_adj;
cycles = findcycles(sparse(G));% can be speed up by just using joints, not every nodes.
kept_joints = zeros(0,1);
for i = 1:length(cycles)
    cycle = cycles{i};
    if length(cycle)<3
        continue
    end
    if show_cycles
        tmp = [cycle, cycle(1)];
        for j = 1:(length(tmp)-1)
            myedge3(M.skelver(tmp(j),:), M.skelver(tmp(j+1),:), 'Color',[1 0 0]);
        end
    end
    
    if length(cycle)>threshold, continue, end;
    % delete the small cycle.  
    for j = 1:length(cycle)  
        if ismember(cycle(j), joints(:,1))% a joint
            id = cycle(j);
            cycle(j)=[];
            cycle = [id, cycle];
            break;
        end
    end
    M.skelver( cycle(1),: ) = mean( M.skelver( cycle,: ) ); 
    kept_joints(end+1,:) = cycle(1);
    
    for j = 2:length(cycle)      
        M.skelver( cycle(j),: ) = NaN; 
        segments( cycle(j) ) = 0; 
        % update the correspondents
        M.corresp( M.corresp==cycle(j) ) = cycle(1);
        
        tmp = find( joints(:,1)==cycle(j) );
        if ~isempty(tmp) % a joint  
            % update the A matrix
            for k=1:size(M.skel_adj,1)
                if M.skel_adj(cycle(j),k) == 1, 
                    M.skel_adj(cycle(1),k)=1; 
                    M.skel_adj(k,cycle(1))=1; 
                end
            end
            joints(tmp,:) = [];
        end    
        % remove the row
        M.skel_adj(cycle(j),:) = 0;
        M.skel_adj(:,cycle(j)) = 0;  
    end    
end

if show_cycles && ~isempty(kept_joints)
    figure('Name','Remove small cycles','NumberTitle','off');set(gcf,'color','white');movegui('west');
    plot_skeleton(M, 200);
    scatter3(M.skelver(kept_joints,1),M.skelver(kept_joints,2),M.skelver(kept_joints,3),200,'.b');hold on;    
    axis off; axis equal; camorbit(0,0,'camera'); axis vis3d; view(-90,0);view3d rot;
end