% function [] = compute_bone_heat()
% compute bone heat
% assume that the first node is the root node.

%%
clear;clc;close all;
path(path,'toolbox');
DRAW_INITIALIZE = true;
DRAW_MINDIST = true;
% filename='../result/cylinder1_contract_t(4)_nn(14)_WL(3.438023)_WH(1.000000)_sl(3.000000)_skeleton_r.mat';
filename='../result/horse2_contract_t(4)_nn(30)_WL(9.591142)_WH(1.000000)_sl(3.000000)_skeleton_r.mat';
% filename ='../result/simplejoint_v4770_contract_t(5)_nn(30)_WL(11.810318)_WH(1.000000)_sl(3.000000)_skeleton_r.mat';
load(filename,'M');
scale = 20.0 / M.diameter;
M.verts = M.verts*scale;
M.skelver = M.skelver*scale;
M.diameter = M.diameter*scale;
skelid = find( ~isnan(M.skelver(:,1)) )';% real skeleton nodes.
%% draw the result of initialization
if DRAW_INITIALIZE
    figure;set(gcf,'color','white');hold on;    
    scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),10,'b','filled');%,'filled'
    axis off;    axis equal;   set(gcf,'Renderer','OpenGL'); view3d rot;

    scatter3(M.skelver(:,1),M.skelver(:,2), M.skelver(:,3),10,'r','filled');%,'filled'
    for i=1:size(M.skel_adj,1)
        for j=1:size(M.skel_adj,2)
            if( M.skel_adj(i,j)==1 )
                myedge3(M.skelver(i,:), M.skelver(j,:), 'Color',[1 0 0], 'LineWidth', 2);
            end
        end
    end
end

%% compute nearest bone to each vertex
boneDists = zeros(M.nverts, length(skelid)-1);
for i = 1:M.nverts
    pt = M.verts(i,:);
    for j = 2:length(skelid)
        boneDists(i,j-1) = Global_setting.distP2Seg(pt, M.skelver(skelid(j),:), M.skelver(M.prev(skelid(j)),:));%distance to segment
    end
end

%% compute L and H
L = compute_point_laplacian(M.verts,'conformal',M.rings);%conformal;%spring
% share_threshold = 1+M.diameter*0.0001;
share_threshold = 1.00001;
closset = zeros(1, M.nverts);
H = sparse(M.nverts,M.nverts);
for i = 1:M.nverts
    [C,I] = min(boneDists(i,:));
    closset(i) = I(1);
    I = find(boneDists(i,:) <= C(1)*share_threshold);
    for j = I
        H(i,i) = H(i,i) + 1./(eps+boneDists(i,j)^2);
    end
end
if DRAW_MINDIST
    figure;set(gcf,'color','white');hold on;    
    tmp = full(diag(H));
%     scatter3(M.verts(:,1),M.verts(:,2),M.verts(:,3),10,tmp,'filled');%,'filled'
    options.face_vertex_color = tmp;h2 = plot_mesh(M.verts, M.faces, options);colormap jet(256); colorbar('off');   
    axis off; axis equal; drawnow; hold on;set(gcf,'Renderer','OpenGL');view3d rot;
end

%% compute weights for each bone
figure;set(gcf,'color','white');hold on; 
for i=1:size(M.skel_adj,1)
    for j=1:size(M.skel_adj,2)
        if( M.skel_adj(i,j)==1 )
            myedge3(M.skelver(i,:), M.skelver(j,:), 'Color',[0 1 0], 'LineWidth', 2);
        end
    end
end
skelver = M.skelver(skelid,:);
weights = zeros(M.nverts, length(skelid));
for j = 1:(length(skelid)-1)
    p = zeros(M.nverts,1.0);
    for i = 1:M.nverts
        if boneDists(i,j) < boneDists(i,closset(i))*share_threshold
%            p(i) = 1.0/sum(boneDists(i,:) < boneDists(i,closset(i))*1.00001);
           p(i) = 1.0;
        end        
    end
    
    A = L + H;% left
    b = H * p;% right
    weights(:,j) = A\b; 
    h1 = myedge3(M.skelver(j+1,:), M.skelver(M.prev(j+1),:), 'Color',[1 0 0], 'LineWidth', 6);
    hold on;
%     h2 = scatter3(M.verts(:,1),M.verts(:,2),M.verts(:,3),10, weights(:, j), 'filled'); 
    options.face_vertex_color = weights(:,j);h2 = plot_mesh(M.verts, M.faces, options);colormap jet(256); colorbar('off');   
    axis off; axis equal; drawnow; hold on;set(gcf,'Renderer','OpenGL');view3d rot;
    delete(h1);
    delete(h2);
end

%% normalization
tmp = sum(weights,2);
weights = weights./repmat(tmp,1,size(weights,2));
M.weights = weights;
save([filename(1:end-4), '_w.mat'], 'M');
