% test_read_attachment
clear all;
clc;
path(path,'toolbox') 
filename = '../data/test.off'; 
skl_filename = '../data/test.skeleton'; 
att_filename = '../data/test.attachment';
my_filename = '../data/test_w.mat';
close all;
%% initialize point cloud
load(my_filename,'M');
[P.verts,P.faces] = read_mesh(filename);
P.nverts = size(P.verts,1);
[P.skelver, P.skel_adj, P.prev] = read_skeleton(skl_filename);
skelid = find( ~isnan(P.skelver(:,1)) )';% real skeleton nodes.
P.attachment = read_attachment(att_filename, P.nverts);
%% draw the result of initialization
figure;set(gcf,'color','white');hold on;    
scatter3(P.verts(:,1),P.verts(:,2), P.verts(:,3),10,'b','filled');%,'filled'
axis off;    axis equal;   set(gcf,'Renderer','OpenGL'); view3d rot;

scatter3(P.skelver(:,1),P.skelver(:,2), P.skelver(:,3),10,'r','filled');%,'filled'
for i=1:size(P.skel_adj,1)
    for j=1:size(P.skel_adj,2)
        if( P.skel_adj(i,j)==1 )
            myedge3(P.skelver(i,:), P.skelver(j,:), 'Color',[1 0 0], 'LineWidth', 2);
        end
    end
end
%% draw weights for each bone
figure;set(gcf,'color','white');hold on;   
for i=1:size(P.skel_adj,1)
    for j=1:size(P.skel_adj,2)
        if( P.skel_adj(i,j)==1 )
            myedge3(P.skelver(i,:), P.skelver(j,:), 'Color',[0 1 0], 'LineWidth', 2);
        end
    end
end
skelver = P.skelver(skelid,:);
for j = 1:(length(skelid)-1)
    h1 = myedge3(P.skelver(j+1,:), P.skelver(P.prev(j+1),:), 'Color',[1 0 0], 'LineWidth', 6);
    hold on;
%     h2 = scatter3(P.verts(:,1),P.verts(:,2),P.verts(:,3),10, P.attachment(:, j), 'filled'); 
    options.face_vertex_color = P.attachment(:,j);h2 = plot_mesh(P.verts, P.faces, options);colormap jet(256); colorbar('off');   
    axis off; axis equal; drawnow; hold on;set(gcf,'Renderer','OpenGL');view3d rot;
    delete(h1);
    delete(h2);
end

