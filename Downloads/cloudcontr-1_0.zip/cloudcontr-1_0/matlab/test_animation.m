%% animation
clear;clc;close all;
path(path,'toolbox');
DRAW_INITIALIZE = true;
filename='../result/test_animation_w.mat';
motionfile = '../result/test_animation_w_m1_2.txt';%motionfile=[filename(1:end-4), '_m.txt'];
weightfile='../data/test_animation.attachment';
% filename='../result/cylinder1_contract_t(4)_nn(14)_WL(3.438023)_WH(1.000000)_sl(3.000000)_skeleton_r_w.mat';
%% initialize
close all;
load(filename,'M');
% M.weights = read_attachment(weightfile, M.nverts);
motions = read_motion(motionfile);% load([filename(1:end-4), '_m.mat'],'motions');
mstep = size(motions,1);

figure; view3d rot; hold on;set(gcf,'color','white');
model_handle = scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),20,'r', 'filled'); 
set(model_handle, 'BusyAction', 'queue');
set(model_handle, 'Interruptible', 'on');
 
axis off; axis equal; set(gcf,'Renderer','OpenGL');
% set(gca,'nextplot','replacechildren');

while true
    verts = M.verts;
    skelver = M.skelver;
    for i = 1:mstep
        motion = reshape(motions(i,:),7,size(M.skelver,1)+1)';
%         for j = 2:size(skelver,1)
%             skelver(j,:) = quatrotate(motion(j,1:4) ,M.skelver(j,:));            
%         end
%         clf;set(gcf,'color','white');
%         for j=1:size(M.skel_adj,1)
%             for k=1:size(M.skel_adj,2)
%                 if( M.skel_adj(j,k)==1 )
%                     myedge3(skelver(j,:), skelver(k,:), 'Color',[1 0 0], 'LineWidth', 1);
%                 end
%             end
%         end
%         axis off;    axis equal;   set(gcf,'Renderer','OpenGL'); view3d rot; hold on;   
%         camorbit(0,0,'camera'); axis vis3d; view(0,80);
            
        for j = 1:M.nverts
            rot = [0,0,0,0];
            for k = 2:size(skelver,1)
                rot = rot + motion(k,1:4) * M.weights(j,k-1);                
            end
            verts(j,:) = quatrotate(rot ,M.verts(j,:));
        end      
        set(model_handle, 'xdata',verts(:,1), 'ydata', verts(:,2), 'zdata', verts(:,3));        
%         scatter3(verts(:,1),verts(:,2), verts(:,3),20,'r', 'filled');     
        drawnow;
    end
end

if DRAW_INITIALIZE
    figure;set(gcf,'color','white');hold on;    
    scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),10,'b','filled');%,'filled'
    axis off;    axis equal;   set(gcf,'Renderer','OpenGL'); view3d rot;

    scatter3(M.skelver(:,1),M.skelver(:,2), M.skelver(:,3),10,'r','filled');%,'filled'
    scatter3(M.skelver(1,1),M.skelver(1,2), M.skelver(1,3),60,'r','filled');%,'filled'
    for i=1:size(M.skel_adj,1)
        for j=1:size(M.skel_adj,2)
            if( M.skel_adj(i,j)==1 )
                myedge3(M.skelver(i,:), M.skelver(j,:), 'Color',[1 0 0], 'LineWidth', 1);
            end
        end
    end
    draw_axis(M.bbox(1:3), 1);    
end

motion = reshape(motions(1,:),7,size(M.skelver,1)+1)';
% % for Pinocchio, not finshed!
% %%
% rot = [1,0,0]*pi*0.5;
% tral = [0,1,0];
% verts = qrot3d(M.verts,rot,norm(rot));
% h = scatter3(verts(:,1),verts(:,2), verts(:,3),10,'g','filled');
% 
% %%
% rots = cell(mstep, length(skelid)+1);
% trls = cell(mstep, length(skelid)+1);
% tmp = length(skelid)*2+1;
% for i=1:mstep
%     for j=1:2:tmp            
%         rots{i,(j+1)/2} = motions(i,3*j-2:3*j);
%         trls{i,(j+1)/2} = motions(i,3*j+1:3*j+3);
%     end
% end
% 
% frots = cell(size(rots));
% ftrls = cell(size(trls));
% for i=1:mstep
%     for j = 2:length(skelid)% for each bone
%         frots{i,j} = rots{i,j};
%         ftrls{i,j} = trls{i,j};
%         prev = M.prev(j);
%         while(prev)    
%             frots{i,j} = rots{i,M.prev(prev)}*frots{i,j};
%             ftrls{i,j} = trls{i,M.prev(prev)}*ftrls{i,j};
%             prev = M.prev(prev);
%         end
%     end
% end
% %% animation
% figure;axis off; axis equal;set(gcf,'Renderer','OpenGL');view3d rot;set(gcf,'color','white');
% scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),20,'b', 'filled');
% hold on;
% line( [0,1], [0,0], [0,0],'Color','r'); text(1,0,0,'x');
% line( [0,0], [0,1], [0,0],'Color','g'); text(0,1,0,'y');
% line( [0,0], [0,0], [0,1],'Color','b'); text(0,0,1,'z');
% 
% handle = 0;
% verts = M.verts;
% for i=1:mstep
%     for j = 1:M.nverts
%         rot = zeros(3,3);
%         for k = 2:length(skelid)
%             rot = rot + frots{i,k}*M.weights(i,k);
%         end
%         verts(j,:) = qrot3d(verts(j,:),rot,norm(rot)) + tral;
%     end    
%     if handle, delete(handle), end;
%     handle = scatter3(verts(:,1),verts(:,2), verts(:,3),20,'r', 'filled');
%     draw now;
% end
