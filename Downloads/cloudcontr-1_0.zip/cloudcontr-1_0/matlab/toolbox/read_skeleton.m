function [skelver, skel_adj, prev] = read_skeleton(skl_filename)
% skl_filename = '../data/cylinder1.skeleton'; 
fid = fopen(skl_filename,'r');
if( fid==-1 )
    error('Can''t open the file.');
    return;
end

A = fscanf(fid, '%d %f %f %f %d');
fclose(fid);

A = reshape(A, 5, length(A)/5.0)';
skelver = A(:,2:4);
prev = A(:,5)+1;

skel_adj = eye(size(A,1));
for i = 1:size(A,1)
    if prev(i)>0
        skel_adj(i, prev(i)) = 1;
        skel_adj(prev(i), i) = 1;
    end
end

