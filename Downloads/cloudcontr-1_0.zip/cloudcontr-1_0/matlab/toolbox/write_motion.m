function [] = write_motion(filename, motions)
fid = fopen(filename,'w');
if( fid==-1 )
    error('Can''t open the file.');
    return;
end

%% for my format
cols = size(motions,2)/7;
row = ['%f %f %f %f %f %f %f '];
row = repmat(row,1,cols);
fprintf(fid, [row '\n'], motions');
fclose(fid);

%% for Pinocchio's format
% cols = size(motions,2)/6;
% row = ['%f %f %f %f %f %f '];
% row = repmat(row,1,cols);
% fprintf(fid, [row '\n'], motions');
% fclose(fid);