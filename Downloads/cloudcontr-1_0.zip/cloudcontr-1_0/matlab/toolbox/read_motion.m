function motions = read_motion(filename)

fid = fopen(filename,'r');
if( fid==-1 )
    error('Can''t open the file.');
    return;
end

i=0;
while~feof(fid)
    fgetl(fid);
    i=i+1;
end
frewind(fid);

% for my format
A= fscanf(fid,'%f %f %f %f %f %f %f');
len = size(A,1)*size(A,2);
A = reshape(A, len/i, i);
motions = A';
fclose(fid);

% for Pinocchio's format
% A= fscanf(fid,'%f %f %f %f %f %f');
% len = size(A,1)*size(A,2);
% A = reshape(A, len/i, i);
% motions = A';
% fclose(fid);
