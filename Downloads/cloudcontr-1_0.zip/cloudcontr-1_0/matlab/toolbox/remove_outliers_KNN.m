% remove outliers by KNN
%%
filename = '../data/fertility_2n.off';
[M.verts,M.faces, M.normals] = read_mesh(filename);
M.nverts = size(M.verts,1);
M.k_knn = Global_setting.compute_k_knn(M.nverts);
atria = nn_prepare(M.verts); % OpenTSTool,������k����
[M.knn_idx, M.knn_dist] = nn_search(M.verts, atria, M.verts, M.k_knn);

figure;set(gcf,'color','white');hold on;   
axis off; axis equal; ;set(gcf,'Renderer','OpenGL');view3d rot;
scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),20,'g','filled');
%%
out_idx = zeros(0,1);
for i=1:M.nverts
    neighs = M.knn_idx(i,:);
    k = 0;
    for j=neighs
        if ismember(i, M.knn_idx(j,:))
            k = k+1;
        end
    end
    if k < M.k_knn*0.3
        out_idx(end+1) = i;
    end
end
scatter3(M.verts(out_idx,1),M.verts(out_idx,2), M.verts(out_idx,3),30,'r','filled');

M.verts(out_idx,:) = [];
if ~isempty(M.normals)
    M.normals(out_idx,:) = [];
end
write_off([filename(1:(end-4)) '_noOutlier.off'], M.verts, M.faces, M.normals);