function areas = area_1_face_ring(verts,faces, rings)

% if exist('rings','var') ==0
%     rings = compute_vertex_face_ring(faces);
% end

areas = zeros(length(rings),1);
n = size(areas,1);
fareas = compute_fareas(verts, faces);

for i = 1:n
    ring = rings{i};
    for b = ring
        areas(i) = areas(i) + fareas(b);
    end
end

function fareas = compute_fareas(verts, faces)
nf = size(faces,1);
fareas = zeros(nf, 1);
for b = 1:nf
    bf = faces(b,:);
    vi = verts(bf(1),:); vj = verts(bf(2),:); vk = verts(bf(3),:);
    fareas(b) = fareas(b) + 0.5 * norm(cross(vi-vk,vi-vj));
end