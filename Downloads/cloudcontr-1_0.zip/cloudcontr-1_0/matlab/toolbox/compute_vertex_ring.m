function vrings = compute_vertex_ring(faces, frings)

% compute_vertex_ring - compute the 1 ring of each vertex in a triangulation.
%
%   vrings = compute_vertex_ring(faces, frings);
%
%   vrings{i} is the set of vertices that are adjacent
%   to vertex i.
%
%  Copyright (c) 2009 JJCAO

% create empty cell array
nverts = length(frings);
vrings{nverts} = [];
for i = 1:nverts
    fring = frings{i};
    neighs = faces(fring,:);
    a = neighs<i;
    b = neighs==i;
    neighs(a)=neighs(a)+1;
    neighs(b)=1;
    neighs = sort(neighs,2);
    neighs = neighs(:,2:end);
    
    % ��һ���ĵ�һ�����㣺����г���һ�εĶ��㣬��Ϊ��㣬������ȡһ��
    x=neighs(:);
    x=sort(x);
    d=diff([x;max(x)+1]);
    count = diff(find([1;d])); % ÿ�����ֳ��ֵĴ���
    y =[x(find(d)) count];
    n_sorted_index = size(y,1);
    start = find(count==1);
    if ~isempty(start) % �����ֻ����һ�εĶ���
        want_to_find = y(start(1),1);
    else
        want_to_find = neighs(1,1);
        n_sorted_index = n_sorted_index+1; % ��λ�Ƿ�յĻ�
    end
    
    j = 0;    
    sorted_index = zeros(1,n_sorted_index);
    while j < n_sorted_index
        j = j+1;
        sorted_index(j) = want_to_find;
        [row,col] = find(neighs == want_to_find);
        if ~isempty(col)
            if col(1) == 1
                want_to_find = neighs(row(1),2);
                neighs(row(1),2) = -1;
            else
                want_to_find = neighs(row(1),1);
                neighs(row(1),1) = -1;
            end    
        end
    end
    
    % ��λΪ�˵㣬����������Ƿ�յģ�����λ������ͬ������ͬ    
    a = sorted_index<=i;
    sorted_index(a)=sorted_index(a)-1;
    
    vrings{i} = sorted_index;
end
% % old 2009 version 1, halfedge does not support large matrix!
% Mifs = indexedfaceset(verts, faces);
% Mhe = halfedge(Mifs);
% vrings = Mhe.vertex_neighbors;
% 
% for i = 1:length(vrings)
%     i
%     vrings{i}(end+1) = vrings{i}(1);
% end

% %old (Copyright (c) 2004 Gabriel Peyr), the neighbors around the vertex i do not have a order.
% [tmp,face] = check_face_vertex([],face);
% nverts = max(max(face));
% A = triangulation2adjacency(face);
% [i,j,s] = find(sparse(A));
% % create empty cell array
% vring{nverts} = [];
% for m = 1:length(i)
%     vring{i(m)}(end+1) = j(m);
% end