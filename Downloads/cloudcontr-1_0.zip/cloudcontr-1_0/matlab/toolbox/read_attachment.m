function weights = read_attachment(filename, nverts)
% filename = '../data/test.attachment'; 
fid = fopen(filename,'r');
if( fid==-1 )
    error('Can''t open the file.');
    return;
end

weights = fscanf(fid, '%f');
fclose(fid);

weights = reshape(weights, length(weights)*1.0/nverts, nverts)';