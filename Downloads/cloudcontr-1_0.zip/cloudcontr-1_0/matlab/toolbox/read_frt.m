function [frontIds,rigidity,color] = read_frt(filename)
% rigidity s color(1) color(2) color(3) numFront
% vertIds
fid = fopen(filename,'r');
if( fid==-1 )
    error('Can''t open the file.');
    return;
end

str = fgets(fid);   % -1 if eof
if ~strcmp(str(1:6), 'FRONTS')
    error('The file is not a valid FRONTS one.');    
end
str = str(7:end);
NumF = str2double(str); % The number of the front
frontIds = cell(NumF,1);
color = zeros(1,3);
for i = 1:2*NumF
    if ~mod(i,2)
        str = fgets(fid);
        frontIds{i/2} = str2num(str) + 1;
    else
        str = fgets(fid);
        tmp = str2num(str);
        rigidity = tmp(1);
        color = tmp(3:5);
    end
end