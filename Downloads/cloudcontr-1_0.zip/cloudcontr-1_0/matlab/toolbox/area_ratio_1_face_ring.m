function ratios = area_ratio_1_face_ring(overts, verts, faces, rings)
ofareas = compute_fareas(overts, faces);
fareas = compute_fareas(verts, faces);
areaRatio = fareas./ofareas;
ratios = zeros(length(rings),1);
n = size(ratios,1);
for i = 1:n
    ring = rings{i};
    for b = ring
        ratios(i) = ratios(i) + areaRatio(b);
    end
    ratios(i) = ratios(i)/length(ring);
end

function fareas = compute_fareas(verts, faces)
nf = size(faces,1);
fareas = zeros(nf, 1);
for b = 1:nf
    bf = faces(b,:);
    vi = verts(bf(1),:); vj = verts(bf(2),:); vk = verts(bf(3),:);
    fareas(b) = fareas(b) + 0.5 * norm(cross(vi-vk,vi-vj));
end