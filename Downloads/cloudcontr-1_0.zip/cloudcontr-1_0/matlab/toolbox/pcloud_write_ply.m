% PCLOUD_WRITE_PLY writes the point cloud to a ply file
%
% SYNTAX
% pcloud_write_ply(P, filename)
%
% INPUT PARAMETERS
%   P: point cloud with N points in pcloud format with the following subfields
%       - P.points: the location of points in the cloud [Nx3] matrix
%       - P.normals: (optional) the normals of the point cloud [Nx3] matrix
%
% DESCRIPTION
% Creates a ply file containing the point cloud.
% This is an example of ply file:
% 
% -------------------------------------------------------------
% ply
% format ascii 1.0
% element vertex 34411
% property float x
% property float y
% property float z
% property float nx
% property float ny
% property float nz
% end_header
% -74.250667 78.957530 465.753420 -0.218310 -0.351003 -0.910570
% -73.918707 78.955766 470.351801 -0.218310 -0.351003 -0.910570
% -73.182817 77.882380 465.860229 -0.218310 -0.351003 -0.910570
% ....
% -------------------------------------------------------------
%
% Examples:
% creates a random distribution, random normals pointcloud and output
% it to a "ply" file
% >> N = 10000;
% >> P.points = randn(N,3);
% >> P.normals = randn(N,3);
% >> pcloud_write_ply(P, 'example.ply');
%
% See also:
% PCLOUD_READ_PLY
%

% Copyright (c) 2008 Andrea Tagliasacchi
% All Rights Reserved
% email: ata2@cs.sfu.ca 
% $Revision: 1.0$  Created on: 2008/09/24
function pcloud_write_ply(P, filename)

if isfield(P,'normals')
    if size(P.points, 2) ~= 3 || size(P.normals, 2) ~= 3
       error('the points and normals matrixes should have at least 3 columns');
    end
    % open the file
    fid = fopen(filename,'w');
    if fid == -1
        error(['ERROR: could not open file "' filename '"']);
    end
    % write header
    fprintf(fid, 'ply\n');
    fprintf(fid, 'format ascii 1.0\n');
    fprintf(fid, 'element vertex %d\n', size(P.points,1) );
    fprintf(fid, 'property float x\n');
    fprintf(fid, 'property float y\n');
    fprintf(fid, 'property float z\n');
    fprintf(fid, 'property float nx\n');
    fprintf(fid, 'property float ny\n');
    fprintf(fid, 'property float nz\n');
    fprintf(fid, 'end_header\n');
    % write the points/normals
    for i=1:size(P.points,1)
        fprintf(fid, '%f %f %f %f %f %f\n', P.points(i,:), P.normals(i,:) );
    end
else
    if size(P.points, 2) ~= 3
       error('the points matrix should have at least 3 columns');
    end
    % open the file
    fid = fopen(filename,'w');
    if fid == -1
        error(['ERROR: could not open file "' filename '"']);
    end
    % write header
    fprintf(fid, 'ply\n');
    fprintf(fid, 'format ascii 1.0\n');
    fprintf(fid, 'element vertex %d\n', size(P.points,1) );
    fprintf(fid, 'property float x\n');
    fprintf(fid, 'property float y\n');
    fprintf(fid, 'property float z\n');
    fprintf(fid, 'end_header\n');
    % write the points/normals
    for i=1:size(P.points,1)
        fprintf(fid, '%f %f %f\n', P.points(i,:) );
    end
end
disp( sprintf('pcloud file written in ply file: %s', filename) );

% Close file
fclose(fid);