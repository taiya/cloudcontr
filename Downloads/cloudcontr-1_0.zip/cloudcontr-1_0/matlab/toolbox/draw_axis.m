function [] = draw_axis(origin, scale)
    line( [origin(1),origin(1)+scale], [origin(2),origin(2)], [origin(3),origin(3)],'Color','r'); 
    text(origin(1)+scale,origin(2),origin(3),'x');
    line( [origin(1),origin(1)], [origin(2),origin(2)+scale], [origin(3),origin(3)],'Color','g'); 
    text(origin(1),origin(2)+scale,origin(3),'y');
    line( [origin(1),origin(1)], [origin(2),origin(2)], [origin(3),origin(3)+scale],'Color','b'); 
    text(origin(1),origin(2),origin(3)+scale,'z');