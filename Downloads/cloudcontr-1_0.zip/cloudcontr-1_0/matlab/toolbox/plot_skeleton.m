function [] = plot_skeleton(M, sizev, sizee)
if nargin < 2, sizev = 600; end
if nargin < 3, sizee = 2; end
skelv_color = [1, .8, .8];% light red
% skelv_color = [0, .0, .1];% blue
skele_color = [1, .0, .0];%  red
if sizev <= 0
    sizev = 0.01;
end
scatter3(M.skelver(:,1),M.skelver(:,2),M.skelver(:,3),sizev,'.','MarkerEdgeColor',skelv_color); hold on;

for i=1:size(M.skel_adj,1)
    for j=1:size(M.skel_adj,2)
        if( M.skel_adj(i,j)==1 )
%             myedge3(M.skelver(i,:), M.skelver(j,:), 'LineWidth', sizee,'Color',skele_color);
            idx = [i;j];
            line( M.skelver(idx,1),M.skelver(idx,2),M.skelver(idx,3), 'LineWidth', sizee,'Color',skele_color);
%             text(M.skelver(i,1),M.skelver(i,2),M.skelver(i,3),int2str(i)) 
        end
    end
end