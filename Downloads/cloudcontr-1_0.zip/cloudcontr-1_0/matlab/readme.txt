the entrance: eg_skeleton_laplacian_rosa.m 
	Global_setting.m
	contraction_by_mesh_laplacian.m

	rosa_lineextract_andrea.m (we RECOVER CONNECTIVITY after each edge collapse, which is slow, but the result sampling is more uniform.)
	rosa_lineextract.m(we update CONNECTIVITY after each edge collapse, which is faster, but the result sampling is not very uniform.)
	rosa_lineextract_set.m (want to extract same skeleton from two different poses, failed, since the connectivity graphs formed by furthest point sampling are different!)

the post-process: refine_skeleton.m (there are some switches.)

eg_segmentation.m
eg_animation.m
compute_bone_heat.m
test_bone_heat.m
test_mesh_bone_heat.m
