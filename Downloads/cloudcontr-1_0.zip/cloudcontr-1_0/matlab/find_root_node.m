function [root_id, global_dist] = find_root_node(M, joints, show_root)
if isempty(joints)
    root_id = 1;
else
    [c, root_id] = max(joints(:,2));
    root_id = joints(root_id,1);
end

local_dist = zeros( size(M.skel_adj)); % local distance matrix
for i=1:size(M.skel_adj,1)
    for j=1:size(M.skel_adj,2)
        if( M.skel_adj(i,j)==1 )
            rs = M.skelver(i,:) - M.skelver(j,:);
            local_dist(i,j) = sqrt(dot(rs,rs));
        end
    end
end

global_dist = compute_distance_graph(sparse(local_dist), root_id);

% draw joints, draw roots; 
if show_root
%     figure('Name','Find root joint','NumberTitle','off');set(gcf,'color','white');movegui('west');
%     plot_skeleton(M, 200);hold on;
%     scatter3(M.skelver(joints(:,1),1),M.skelver(joints(:,1),2),M.skelver(joints(:,1),3),200,'b', 'filled');
    scatter3(M.skelver(root_id,1),M.skelver(root_id,2),M.skelver(root_id,3),400,'r', 'filled');
%     axis off; axis equal; camorbit(0,0,'camera'); axis vis3d; view(-90,0);view3d rot;
end