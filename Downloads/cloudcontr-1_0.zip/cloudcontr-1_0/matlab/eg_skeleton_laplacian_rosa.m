% function [] = eg_point_cloud_curve_skeleton(filename)
% extract point cloud curve skeleton
% create-date: 2009-4-26
% by: JJCAO, deepfish @ DUT
%
clear;clc;close all;
%% ------------ test00 simple model-------------------
% filename = '../data/cylinder1.off';
% filename = '../data/v2.off'; 
% filename = '../data/knight_2992.off'; 
filename = '../data/simplejoint_v4770';
% filename = '../data/horse_v1987_refined.off';% ear part bad
% filename = '../data/horse_v11912';
%% out of body
% filename = '../data/Hand_22932.off';
%% ------------ test01 noisy model -------------------
% filename = '../data/fertility_5view_overlap_0.005.off';
% filename = '../data/P_N_0.005.off';
% filename = '../data/horse_v11912_random_0.030000';
% options.WL = 6.393380;
% filename = '../data/fertility_nonuniform_8862.off';%excellent
% filename = '../data/fertility_nonuniform_16239.off';%bad, has an extrema
%filename = '../data/noise/Dinopet_0.25.off';%good
% filename = '../data/noise/Dinopet_0.5.off';%OK
% filename = '../data/Dinopet_gaussian_0.003000.off';%bad
% filename = '../data/noise/horse1_0.25.off';
% options.WC = 1;
%% ------------test02 genus -----------------------
% filename = '../data/pegaso_v10008.off';%excelent!
% filename = '../data/pegaso_v10975.off';%bad
% filename = '../data/pegaso_v13720.off';%excelent
% options.WL = 40;
% options.WC = 10;
% ptions.sl = 2;
% filename = '../data/fertilty_v10494.off'; % excelent
% filename = '../data/fertilty.off';
% filename = '../data/elk'; % excelent
% filename = '../data/elk_v12006'; % a little bad
% filename = '../data/9HandleTorus_v2044.off';%contracion 
% filename = '../data/9HandleTorus';%contracion 
% filename = '../data/heptoroid_v14294.off';%contracion 
% filename = '../data/knot2.off';
% filename = '../data/dancer2_v11281.off';
% filename = '../data/dancer_v10500.off';
% filename = '../data/neptune_v11488'; 
% filename = '../data/happy_v12213.obj';%bad
% options.WL = 10*5;
% filename = 'torus_v1280.off';
% filename = 'knot20_v2291.off';
% filename = '../data/genus3.off';
%% ------------ test03 missing data -------------------
% filename = '../data/runman1s1'; 
% filename = '../data/woman'; % some points locate in same position, which lead to bad local triangulation 
% filename = '../data/woman_11690'; 
% filename = '../data/woman'; 
% options.WL = 14.439483*3;
% options.sl = 3;
% filename = '../data/runman1s1_noOutlier.off'; 
% filename = '../data/fertility_2n'; 
% filename = '../data/fertility_1n_noOutlier.off';
% filename = '../data/indolady5_v11125.off'; 

% filename = '../data/horse_miss_v10556.off'; 
% filename2='horse_miss_v10556_contract_t(5)_nn(30)_WL(10.274240)_WH(1.000000)_sl(3.000000).off';
% filename = '../data/horse_miss_11773.off';
% filename = '../data/armadillo_v8651_miss2.off';
% filename2='armadillo_v8651_miss2_contract_t(4)_nn(30)_WL(9.301075)_WH(1.000000)_sl(3.000000).off';
%% ------------ test04 pose and sampling -------------------
% filename = '../data/horse1.off';
% filename = '../data/horse7.off';

% filename = '../data/armadillo_v502';
% filename = '../data/armadillo_v1297';
% filename = '../data/armadillo_v5189';
% filename = '../data/armadillo_v10378';

% filename = '../data/armadillo_43244.obj';
% filename = '../data/armadillo_v8651.off';
% filename = '../data/armadillo_v13840.off';
%% ------------ test05 consistent segmentation-------------------
% filename = '../data/horse3.off';
% % options.WL = 11.128173514970236; % compute automatically now.
% options.WC = 1;
% filename2='horse2_contract_t(4)_nn(30)_WL(9.591142)_WH(1.000000)_sl(3.000000).off';
%% ------------test06 machines -----------------------
% filename = '../data/mechpart.off';
% filename = '../data/796_raw_merge.off'; %bad, so the thinning process need consider more geometry error.
% options.WL=5.195239;
% options.WH=2;
% options.sl=2;
%% ------------test07 animals -----------------------
% filename = '../data/memento_v11038.off';%wonderful
% filename = '../data/eagle_v9928';%wonderful
% filename = '../data/Dinopet.off';% wonderful, each finger
% filename = '../data/raptor_19998';%wonderful
% filename = '../data/dinosaur_10083.off';%wonderful
% filename = '../data/raptor_v10498';% close-by structure.

% filename = '../data/gargoyle_10502.off'; %soso
% filename = '../data/bunny_v10508.off';
% options.WL=7.766184;
% options.WH=1;
% options.sl=2;
% filename = '../data/camel_10939.off';
% filename = '../data/cow2.off';% closeby
% filename = '../data/dilo_v13588';
% filename = '../data/dinosaur-vmc.off';% ok
% filename = '../data/dragon_v_10870.obj';%bad
% filename = '../data/elephant_v15169.off';
% filename = '../data/female_v4040.off';
% filename = '../data/HIPPO_v2315.off';
% filename = '../data/octopus_8476.off';
% filename = '../data/octopus.off';
% filename = '../data/polygirl.off';
% filename = '../data/shark.off';% bad, too sparse
%% ------------ real data ----------------------- 
% filename = '../data/1364_PierreHand3Fingers_clean_v26305(0.01)';
% filename = '../data/1338_Galaad_clean_v29029';
% filename = '../data/armadillo_Poisson_o7_24140';
% filename = '../data/bunny';
% filename = '../data/1338_Galaad_noise.obj'; %good
% filename = '../data/1338_Galaad_clean.obj';%good
% filename = '../data/1338_Galaad_clean_v10109';
% filename = '../data/MagaliHand1_v18691.obj';
% filename = '../data/armadillo_v8648.obj';
% filename = '../data/santa_v7346.obj';
%% ------------ open boundary ----------------------- 
% filename = '../data/m324_v10002.off';
% filename = '../data/corn_leaf.off';% cool
% filename = '../data/corn_v12108.off';% cool
% filename = '../data/corn_26441.off';% cool
%% ------------ limitations -----------------------
% filename = '../data/feline_v12465.off';%nearby structure
% filename = '../data/dancing_children_v17989.off';
% options.sl=2;
% options.WL = 11.104998*0.5;
% options.WC = 4;
% filename = '../data/dancing_children_v10113.off'; %bad
% filename = '../data/tobacco_v4647.off';% bad, 
% filename = '../data/tobacco_v8098.off';% bad, 
% options.WL = 10.848823*10;
% options.WH = 1;
%##########################################################################

% matlabpool
%% setting
%##########################################################################
path('toolbox',path);
options.USING_POINT_RING = GS.USING_POINT_RING;
extension='.off';

tic
M.filename = [filename extension];
[M.verts,M.faces] = read_mesh(M.filename);
M.nverts = size(M.verts,1);
if exist([filename '_fe.txt'],'file')
    M.radis = load([filename '_fe.txt']);
else
    M.radis = ones(M.nverts,1);
end

M.verts = GS.normalize(M.verts);
[M.bbox, M.diameter] = GS.compute_bbox(M.verts);
disp(sprintf('read mesh:'));
toc

tic
atria = nn_prepare(M.verts); % OpenTSTool,find kNN
M.k_knn = GS.compute_k_knn(M.nverts);
% M.k_knn = 10;
% [M.knn_idx, M.knn_dist] = nn_search(M.verts, atria, M.verts, M.k_knn);    
% disp(sprintf('compute knn:'));
if options.USING_POINT_RING
    M.rings = compute_point_point_ring(M.verts,M.k_knn, [],[],M.radis, GS.MIN_NEIGHBOR_NUM);
%     M.rings = compute_point_point_ring(M.verts,M.k_knn, M.knn_idx,M.knn_dist,M.radis, GS.MIN_NEIGHBOR_NUM);
else    
    M.frings = compute_vertex_face_ring(M.faces);
    M.rings = compute_vertex_ring(M.faces, M.frings);
end

disp(sprintf('compute 1 ring neighbor:'));
toc

%% Step 1: Contract point cloud by Laplacian
tic
[M.cverts, t, initWL, WC, sl] = contraction_by_mesh_laplacian(M, options);
% [M.cverts, t, initWL, WC, sl] = contraction_by_voronoi_laplacian(M, options);
% write_mesh([PathName FileName],M.cverts, M.faces);
% [M.cverts,faces] = read_mesh(filename2);
disp(sprintf('Contraction:'));
toc
%% step 2: Point to curve �C by cluster ROSA2.0
tic
M.sample_radius = M.diameter*0.02;
% M = rosa_lineextract(M, radius);
M = rosa_lineextract_andrea(M,M.sample_radius);
disp(sprintf('to curve:'));
toc
%% show results
figure;movegui('northeast');set(gcf,'color','white')
scatter3(M.verts(:,1),M.verts(:,2),M.verts(:,3),30,'.','MarkerEdgeColor', GS.PC_COLOR);  hold on;
scatter3(M.cverts(:,1),M.cverts(:,2),M.cverts(:,3),30,'.r'); axis off;axis equal;set(gcf,'Renderer','OpenGL');
camorbit(0,0,'camera'); axis vis3d; view(0,90);view3d rot;

% figure;movegui('southeast');set(gcf,'color','white')
% scatter3(M.cverts(:,1),M.cverts(:,2),M.cverts(:,3),30,'.r'); axis off;axis equal;set(gcf,'Renderer','OpenGL');view3d rot;

figure; movegui('center');set(gcf,'color','white');
scatter3(M.verts(:,1),M.verts(:,2),M.verts(:,3),20,'.','MarkerEdgeColor', GS.PC_COLOR);  hold on;
plot_skeleton(M, 400, 2);
axis off;axis equal;set(gcf,'Renderer','OpenGL');view(0,90);view3d rot;
%%
default_filename = sprintf('%s_contract_t(%d)_nn(%d)_WL(%f)_WH(%f)_sl(%f)_skeleton.mat',...
    M.filename(1:end-4), t, M.k_knn, initWL, WC, sl);
save(default_filename,'M');
% matlabpool close;