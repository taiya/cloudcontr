function [M, joints, root_id] = merge_nearby_joints(M, joints, root_id)
while true
    for i=joints(:,1)'    
        edges = find( M.skel_adj(i,:)==1 );
        edges = edges(edges~=i);
        tmp = ismember(edges, joints(:,1)');
        if sum(tmp)~=1, continue, end;

        j = edges(tmp);
        edges = find( M.skel_adj(j,:)==1 );
        edges = edges(edges~=j);
        tmp = ismember(edges, joints(:,1)');
        if sum(tmp)~=1, continue, end;

      % update the location
        M.skelver( i,: ) = mean( M.skelver( [i,j],: ) );
        M.skelver( j,: ) = NaN;
        % update the correspondents
        M.corresp( M.corresp==j ) = i;

        % update the A matrix
        for k=1:size(M.skel_adj,1)
            if M.skel_adj( j,k ) == 1, 
                M.skel_adj( i,k )=1; 
                M.skel_adj( k,i)=1; 
            end
        end
        % remove the row
        M.skel_adj( j,: ) = 0;
        M.skel_adj( :,j ) = 0;

        segments(j) = 0;
        j = find( joints(:,1)==j );
        if root_id == j
            root_id = find( joints(:,1)==i );            
        end
        joints(j,:) = [];
%         break;
    end
    if i == joints(end,1), break, end;
end

%%
figure('Name','Merge nearby joints','NumberTitle','off');set(gcf,'color','white');view3d rot;
movegui('north');
plot_skeleton(M);
axis off; axis equal; camorbit(0,0,'camera'); axis vis3d; view(-90,0);view3d rot;