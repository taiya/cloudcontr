function P = rosa_lineextract_set(Ps, psets, RADIUS)
% @author: Andrea Tagliasacchi
% reformed by jjcao
% @reform-data:     2009-9-3
 
if nargin < 1
    clear;clc;close all;
    original1 = '../data/horse2.off';
    original2 = '../data/horse3.off';
    contract1 = 'horse2_contract_t(3)_nn(30)_WL(9.591142)_WH(1.000000)_sl(2.000000).off';
    contract2 = 'horse3_contract_t(4)_nn(30)_WL(9.591142)_WH(1.000000)_sl(3.000000).off';

    [P.verts,P.faces] = read_mesh(original1);
    P.nverts = size(P.verts,1);
    P.k_knn = Global_setting.compute_k_knn(P.nverts);
    P.rings = compute_point_point_ring(P.verts,P.k_knn);    
    Ps=cell(0,1);
    Ps(end+1,1) = P;
    [pset,faces] = read_mesh(contract1);
    psets=cell(0,1);
    psets(end+1,1) = pset;
    
    [P.verts,P.faces] = read_mesh(original2);
    P.nverts = size(P.verts,1);
    P.k_knn = Global_setting.compute_k_knn(P.nverts);
    P.rings = compute_point_point_ring(P.verts,P.k_knn);
    Ps(end+1,1) = P;
    [pset,faces] = read_mesh(contract2);
    psets=cell(0,1);
    psets(end+1,1) = pset;
    
    [P.bbox, P.radius] = Global_setting.compute_bbox(P.verts);
    RADIUS = P.radius*0.02;
%     figure; 
%     scatter3(pset(:,1), pset(:,2), pset(:,3),10,'b','filled');hold on;axis off; axis equal;set(gcf,'Renderer','OpenGL');

    % visual debug conditions
    SHOW_RESULTS = true;
    SHOW_SAMPLING_PROGRESS = false;
    SHOW_EDGECOLLAPSE_PROGRESS = false;
else
    % visual debug conditions
    SHOW_RESULTS = false;
    SHOW_SAMPLING_PROGRESS = false;
    SHOW_EDGECOLLAPSE_PROGRESS = false;
end

if SHOW_SAMPLING_PROGRESS == true || SHOW_RESULTS == true
    close all;
    figure(1); movegui('northweast');
    mypoint3(psets{1}, '.r', 'markersize', 1);hold on;axis off; axis equal;set(gcf,'Renderer','OpenGL');
    figure(2); movegui('southweast');
    mypoint3(psets{2}, '.r', 'markersize', 1);hold on;axis off; axis equal;set(gcf,'Renderer','OpenGL');
end
if SHOW_SAMPLING_PROGRESS
    figure(3);movegui('northeast');
    figure(4);movegui('southeast');
%     hold on;axis off; axis equal;set(gcf,'Renderer','OpenGL');
end

%--- FURTHEST POINT DOWNSAMPLE THE CLOUD
% use balls of size RADIUS to downsample the point cloud in a furthest sample fashion
kdtree = kdtree_build( pset );
P.skelver = zeros( 0, 3 );
mindst = nan( length(pset), 1 );
P.corresp = zeros( length(pset), 1 );
for k=1:length(pset)
    if P.corresp(k)~=0, continue, end;
        
    %--- query all the points for distances
    mindst(k) = inf; % make sure picked first
    
    %--- initialize the priority queue
    while ~all(P.corresp~=0)
        maxIdx = max_idx( mindst );
        if mindst(maxIdx) == 0
            break
        end

        % query its delta-neighborhood
        [nIdxs, nDsts] = kdtree_ball_query( kdtree, pset(maxIdx,:), RADIUS );

        % if its neighborhood has been marked already, skip ahead
        if all( P.corresp(nIdxs) ~= 0 )
            mindst(maxIdx) = 0; 
            continue;
        end;

        % create new node and update (closest) distances
        P.skelver(end+1,:) = pset(maxIdx,:); %#ok<AGROW>
        for i=1:length(nIdxs)
            if mindst(nIdxs(i))>nDsts(i) || isnan(mindst(nIdxs(i)))
               mindst(nIdxs(i)) = nDsts(i);
               P.corresp(nIdxs(i)) = size(P.skelver,1);
            end
        end

        if SHOW_SAMPLING_PROGRESS == true
            figure(1); mypoint3( pset(maxIdx,:), '*g');
            figure(2); myscatter3( pset, 5, mindst, 'filled');
        end
    end
end

%--- COMPRESS MAHALANOBIS NEIGHBORHOOD MATRIX
% Neighbors of P.skelver is inherited from the skeletal samples to which they correspond
A = zeros( length(P.skelver), length(P.skelver) );
% surf_kdtree = kdtree_build( P.verts );
for pIdx=1:length(pset)
    
    % skip badly conditioned points (projected to weird places as they have very few neighbors)
    if length(P.rings{pIdx})==1, continue; end
       
    %--- use k-nn, better
%     neighs = kdtree_k_nearest_neighbors( surf_kdtree, P.verts(pIdx,:), 10);
    neighs = P.rings{pIdx};
    
    % filter out bad samples again....
    neighs = neighs( bad_sample(neighs)==0 );
    
    if P.corresp(pIdx) == 0, continue, end;
    for nIdx=1:length(neighs)
        if P.corresp(neighs(nIdx)) == 0, continue, end;
        A( P.corresp(pIdx), P.corresp(neighs(nIdx)) ) = 1;
        A( P.corresp(neighs(nIdx)), P.corresp(pIdx) ) = 1;
    end
end
% kdtree_delete( surf_kdtree );

    %--- RECOVER CONNECTIVITY
    % TODO: iterative update, HUGE SPEEDUP! if you don't reconstruct the
    % triangle count, but rather, you update it, it's MUCH MUCH faster
	%
    % recover the set of edges on triangles & count triangles
    tricount = 0;
    tris = zeros(0,3);
    skeds = zeros(0,2);
    skcst = zeros(0,1);
    for i=1:length(P.skelver)
        neighs = sort( find(A(i,:)==1) );
        neighs = neighs( neighs>i );%touch every triangle only once
        for j=1:length(neighs)
            for k=j+1:length(neighs)
                if A(neighs(j),neighs(k)) == 1,
                    tricount = tricount+1;
                    tris(end+1,:) = [i, neighs(j), neighs(k)];
                    skeds(end+1,:) = [i,neighs(j)];                                                        %#ok<AGROW>
                    skcst(end+1,:) = euclidean_distance( P.skelver(i,:), P.skelver(neighs(j),:) );         %#ok<AGROW>
                    skeds(end+1,:) = [neighs(j),neighs(k)];                                                %#ok<AGROW>
                    skcst(end+1,:) = euclidean_distance( P.skelver(neighs(j),:), P.skelver(neighs(k),:) ); %#ok<AGROW>
                    skeds(end+1,:) = [i,neighs(k)];                                                        %#ok<AGROW>
                    skcst(end+1,:) = euclidean_distance( P.skelver(neighs(k),:), P.skelver(i,:) );         %#ok<AGROW>
                    % disp( skeds(end-2:end,:) );
                end
            end
        end
    end
    
%--- EDGE COLLAPSE 
% collapse the adjecency matrix A until the described graph is 1-dimensional
% this inherits some ideas from the Skeleton by Contraction paper.
while true
    %DEBUG: display connectivity and vertexes at every iteration
    if SHOW_EDGECOLLAPSE_PROGRESS
        hpts = mypoint3( P.skelver, '.r'); 
        heds = [];
        for i=1:size(A,1)
            for j=1:size(A,2)
                if( A(i,j)==1 )
                    heds(end+1) = myedge3(P.skelver(i,:), P.skelver(j,:)); %#ok<AGROW>
                end
            end
        end
        drawnow;
        delete(hpts);
        delete(heds);
    end
    
    disp(sprintf('decimating skeletal graph, remaining #%d loops:', tricount));
    
    %--- STOP CONDITION
    % no more triangles? then the structure is 1D
    if tricount == 0, break, end;
    
    %--- DECIMATION STEP + UPDATES
    % collapse the edge with minimum cost, remove the second vertex
    [IGN, idx] = min( skcst );
    edge = skeds(idx,:);
    % update the location
    P.skelver( edge(1),: ) = mean( P.skelver( edge,: ) ); %#ok<AGROW>
    P.skelver( edge(2),: ) = NaN; %#ok<AGROW>
    % update the A matrix
    for k=1:size(A,1)
        if A(edge(2),k) == 1, 
            A(edge(1),k)=1; 
            A(k,edge(1))=1; 
        end
    end
    % remove the row
    A(edge(2),:) = 0;
    A(:,edge(2)) = 0;
    % update the correspondents
    P.corresp( P.corresp==edge(2) ) = edge(1); %#ok<AGROW>
    
    % update the triangles   
    %
    [row,col] = find(tris == edge(2));
    row = sort(row);
    tmptris = tris(row,:);
    [trow,col] = find(tmptris == edge(1));
    todel = row(trow);
    tochange = setdiff(row, todel);
    row3 = zeros(3,1);
    % remove edges belong to triangles to be deleted
    for i=1:size(todel)
        [row1,col] = find(skeds==tris(todel(i),1));       
        [row2,col] = find(skeds(row1,2)==tris(todel(i),2));
        col = row1(row2);
        row3(1) = col(1);

        [row1,col] = find(skeds==tris(todel(i),2));       
        [row2,col] = find(skeds(row1,2)==tris(todel(i),3));
        col = row1(row2);
        row3(2) = col(1);
        
        [row1,col] = find(skeds==tris(todel(i),1));       
        [row2,col] = find(skeds(row1,2)==tris(todel(i),3));
        col = row1(row2);
        row3(3) = col(1);
        
        skeds(row3,:)=[];
        skcst(row3,:)=[];
    end    
    % change triangles, delete triangles
    [row, col] = find(tris(tochange,:)==edge(2));
    for i = 1:length(row)
        tris(tochange(row(i)), col(i)) = edge(1);
    end
    tris(todel,:) = [];
    tricount = length(tris);
    % change edges
    [row,col] = find(skeds==edge(2));
    for i = 1:length(row)
        skeds(row(i),col(i)) = edge(1);
        
        if col(i) == 1
            col(i) = 2;
        else
            col(i) = 1;
        end
        skcst(row(i)) = euclidean_distance( P.skelver(edge(1),:), P.skelver(skeds(row(i), col(i)),:) );         %#ok<AGROW>
    end
end

% save the skeleton adjecency matrix
P.skel_adj = A;

% display extracted structure
if SHOW_RESULTS
    figure(2); movegui('southeast');
    mypoint3( P.skelver, '.r');
    for i=1:size(A,1)
        for j=1:size(A,2)
            if( A(i,j)==1 )
                myedge3(P.skelver(i,:), P.skelver(j,:)); %#ok<AGROW>
            end
        end
    end
end

function maxIdx = max_idx(array)
[maxValue, maxIdx] = max(array);
function dist = euclidean_distance(p1, p2)
v=p1-p2;
dist = sqrt(dot(v,v));
