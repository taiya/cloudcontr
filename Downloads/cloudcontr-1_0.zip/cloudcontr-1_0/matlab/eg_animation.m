%% animation
clear;clc;close all;
path(path,'toolbox');
filename='../result/test_animation_w.mat';
% filename='../result/cylinder1_contract_t(4)_nn(14)_WL(3.438023)_WH(1.000000)_sl(3.000000)_skeleton_r_w.mat';
%%
close all;
load(filename,'M');
% load([filename(1:end-4), '_m.mat'],'motions');
motions = read_motion([filename(1:end-4), '_m.txt']);
skelid = 1:size(M.skelver,1);
mstep = size(motions,1);
tmp = length(skelid)*2-1;
while(true)
    verts=M.verts;
    for i=1:mstep
        for j=1:2:tmp            
            r = motions(i,3*j-2:3*j);
            t = motions(i,3*j+1:3*j+3);
            verts = r*verts+t;
        end
    end
end
R = [0,1,0;-1,0,0;0,0,1];
Rotation_cell = cell(size(M.skelver,1),1);
for i = 1:size(M.skelver,1)
    Rotation_cell{i,1} = eye(3);
end
Rotation_cell{47,1} = R;

% Rotation_cell_all = cell(size(M.nverts,1),1);
verts = M.verts;
for i = 1:M.nverts
    Rotation = zeros(3,3);
    k = 1;
    for j = 1:size(M.skelver,1)
        if(~isnan(M.skelver(j,1)))
            Rotation = Rotation + Rotation_cell{j,1}*M.weights(i,k);
            k = k + 1;
        end
    end
%     Rotation_cell_all{i,1} = Rotation;
    verts(i,:) = M.verts(i,:)*Rotation;
end
figure;axis off; axis equal;set(gcf,'Renderer','OpenGL');view3d rot;set(gcf,'color','white');
hold on;

scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),20,'b', 'filled');
scatter3(verts(:,1),verts(:,2), verts(:,3),20,'r', 'filled');

line( [0,1], [0,0], [0,0],'Color','r'); text(1,0,0,'x');
line( [0,0], [0,1], [0,0],'Color','g'); text(0,1,0,'y');
line( [0,0], [0,0], [0,1],'Color','b'); text(0,0,1,'z');
camorbit(0,0,'camera'); axis vis3d; view(0,0);%view3d rot;
