% build motion data

clear;clc;close all;
path(path,'toolbox');
filename='../result/test_animation_w.mat';
% filename='../result/cylinder1_contract_t(4)_nn(14)_WL(3.438023)_WH(1.000000)_sl(3.000000)_skeleton_r_w.mat';
%% initialize
close all;
load(filename,'M');

figure;set(gcf,'color','white');hold on;    
scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),10,'b','filled');%,'filled'
axis off;    axis equal;   set(gcf,'Renderer','OpenGL'); view3d rot;

scatter3(M.skelver(:,1),M.skelver(:,2), M.skelver(:,3),10,'r','filled');%,'filled'
scatter3(M.skelver(1,1),M.skelver(1,2), M.skelver(1,3),60,'r','filled');%,'filled'
for i=1:size(M.skel_adj,1)
    for j=1:size(M.skel_adj,2)
        if( M.skel_adj(i,j)==1 )
            myedge3(M.skelver(i,:), M.skelver(j,:), 'Color',[1 0 0], 'LineWidth', 1);
            k = M.prev(i);
            if k
                str = sprintf('%d',i);
                text((M.skelver(i,1)+M.skelver(k,1))*0.5,(M.skelver(i,2)+M.skelver(k,2))*0.5,(M.skelver(i,3)+M.skelver(k,3))*0.5,str);
            end
        end
    end
end
origin = [0,0,0];
draw_axis(origin, 1);    
%% edit
verts = M.skelver;
motion = zeros(size(M.skelver,1)+1,7); %a quaternion and a translation per row.
motion(:,1) = 1.0;
motions = zeros(0,size(motion,1)*size(motion,2));
% 2,4,13,16, 3,5,9 % level 1
% % motion 1
% angles = [0,0,0,0,...% body
%       0,-0.15,-0.1, 0,...%right leg
%       0,-0.01,-0.05,0,...%left leg
%       0, 0.2, 0,...%right arm
%       0, 0.2, 0.25];%left arm
% motion 2
angles = -[0,0,0,0,...% body
      0,-0.01,-0.05,0,...%right leg
      0,-0.15,-0.1, 0,...%left leg
      0, 0.2, 0.25,...%right arm
      0, 0.2, 0];%left arm
for j=0.1:0.1:1  
    as = angles*j;
    %% left arm
    i = 17;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h1 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);

    i = 18;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    % q = [cos(pi*0.5*0.5), v*sin(pi*0.5*0.5)];
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    % motion(i,1:4) = motion(i,1:4)*0.1+q*0.9;
    motion(i,1:4) = quatmultiply(motion(i,1:4),motion(M.prev(i),1:4));
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h2 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);
    %% right arm
    i = 14;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h1 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);

    i = 15;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    motion(i,1:4) = quatmultiply(motion(i,1:4),motion(M.prev(i),1:4));
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h2 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);
    % delete(h1);
    % delete(h2);
    %% left leg
    i = 10;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h1 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);

    i = 11;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    motion(i,1:4) = quatmultiply(motion(i,1:4),motion(M.prev(i),1:4));
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h2 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);
    %% right leg
    i = 6;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h1 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);

    i = 7;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    motion(i,1:4) = quatmultiply(motion(i,1:4),motion(M.prev(i),1:4));
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h2 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);
%%
    % motion = zeros(size(M.skelver,1)+1,7); %a quaternion and a translation per row.
    % motion(:,1) = 1.0;
    motions(end+1,:) = reshape(motion',1,size(motion,1)*size(motion,2));
end
for j=0.9:-0.1:0  
    as = angles*j;
    %% left arm
    i = 17;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h1 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);

    i = 18;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    % q = [cos(pi*0.5*0.5), v*sin(pi*0.5*0.5)];
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    % motion(i,1:4) = motion(i,1:4)*0.1+q*0.9;
    motion(i,1:4) = quatmultiply(motion(i,1:4),motion(M.prev(i),1:4));
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h2 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);
    %% right arm
    i = 14;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h1 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);

    i = 15;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    motion(i,1:4) = quatmultiply(motion(i,1:4),motion(M.prev(i),1:4));
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h2 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);
    %% left leg
    i = 10;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h1 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);

    i = 11;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    motion(i,1:4) = quatmultiply(motion(i,1:4),motion(M.prev(i),1:4));
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h2 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);
    %% right leg
    i = 6;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h1 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);

    i = 7;
    v = M.skelver(M.prev(i),:);
    v = v./norm(v);
    angle = pi*as(i);
    motion(i,1:4) = [cos(angle*0.5), v*sin(angle*0.5)];
    motion(i,1:4) = quatmultiply(motion(i,1:4),motion(M.prev(i),1:4));
    verts(i,:) = quatrotate(motion(i,1:4),M.skelver(i,:));
    h2 = myedge3(verts(M.prev(i),:), verts(i,:), 'Color',[0 1 0], 'LineWidth', 2);
%%
    % motion = zeros(size(M.skelver,1)+1,7); %a quaternion and a translation per row.
    % motion(:,1) = 1.0;
    motions(end+1,:) = reshape(motion',1,size(motion,1)*size(motion,2));
end

%% save
write_motion([filename(1:end-4), '_m.txt'], motions);