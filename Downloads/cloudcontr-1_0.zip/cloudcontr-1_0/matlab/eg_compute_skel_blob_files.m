clear,clc;close all;
path('toolbox',path);

%% ------------ build edges ------------
load('centers.mat');
[M.bbox, M.diameter] = GS.compute_bbox(M.verts);
t1 = 0.2;% threshold for edge length
t2 = 0.05;% threshold for external edge length
r1 = 7+2;% threshold for node rigidity 
M.rigidity = M.rigidity+2;% the rigidity of first node is 3 now.
prelevel = 1;
curlevel = 2;

figure;set(gcf,'color','white');movegui('northwest');set(gcf,'Renderer','OpenGL');
% map = colormap(hot(10));
% tmp = map(floor(M.rigidity),:);
id = M.rigidity>=r1;
M.skelver = [M.skelver(1,:); M.skelver(id,:)];
M.level = [M.level(1,:); M.level(id,:)];
nskel = size(M.skelver,1);
% scatter3(M.skelver(:,1),M.skelver(:,2),M.skelver(:,3),600,'.','MarkerEdgeColor',tmp); hold on;
M.skel_adj=[]; plot_skeleton(M);hold on;
axis off; axis equal; camorbit(0,0,'camera'); axis vis3d;view(90,0);view3d rot;
M.skel_adj=zeros(nskel,nskel);
for i = 2:nskel
    if M.level(i) > curlevel
        prelevel = curlevel;
        curlevel = M.level(i);
    end
    preidx = find(M.level(1:i) <= prelevel);
    verts = M.skelver(preidx,:);% vertices of prelevel
    if length(preidx)>1        
        atria = nn_prepare(verts);
        [knn_idx, knn_dist] = nn_search(verts, atria, M.skelver(i,:), 1); 
        nn = knn_idx(1);
    else
        rs = M.skelver(i,:)-verts;
        knn_dist = sqrt(dot(rs,rs));
        nn = 1;
    end
    if knn_dist(1) > M.diameter*t1
        continue;
    end    
    M.skel_adj(preidx(nn),i)=1;
    M.skel_adj(i,preidx(nn))=1;
    idx = [preidx(nn);i];
%     line( M.skelver(idx,1),M.skelver(idx,2),M.skelver(idx,3), 'LineWidth', 2,'Color','r');
%     drawnow expose update;
end
figure;set(gcf,'color','white');movegui('northwest');set(gcf,'Renderer','OpenGL');
plot_skeleton(M);
axis off; axis equal; camorbit(0,0,'camera'); axis vis3d;view(90,0);view3d rot;

%% -------------------- removing irrelevant extrama -------------------------
joints = zeros(nskel,1);
for i = 2:nskel
    links = find( M.skel_adj(i,:)==1 );
    if length(links) > 2 % joint
        joints(i) = 1;
    end
end
for i = 2:nskel
links = find( M.skel_adj(i,:)==1 );
    if length(links) == 1 % end point
        if joints(links)
            rs = M.skelver(i,:)-M.skelver(links,:);
            knn_dist = sqrt(dot(rs,rs));
            if knn_dist < M.diameter*t2
                M.skel_adj(links,i)=0;
                M.skel_adj(i,links)=0;                
            end
        end
    end
end

figure;set(gcf,'color','white');movegui('northeast');set(gcf,'Renderer','OpenGL');
plot_skeleton(M);hold on;
axis off; axis equal; camorbit(0,0,'camera'); axis vis3d;view(90,0);view3d rot;

%% remove non connected graph
for i = 2:nskel
    links = find( M.skel_adj(i,:)==1 );
    if isempty(links)
        M.skelver(i,:) = nan;
    end    
end

[M, graph] = build_graph(M);% may contain cycles
fid = fopen(['woman.cg'],'w');
if( fid~=-1 )
    fprintf(fid, '# D:3 NV:%d NE:%d\n', size(M.skelver,1), size(graph,1));
    fprintf(fid, 'v %f %f %f\n', M.skelver(:,1:3)');
    fprintf(fid, 'e %d %d\n', graph');
    fclose(fid);
end