function M = rosa_lineextract(M, RADIUS)
% we RECOVER CONNECTIVITY after each edge collapse, which is slow, but the
% result sampling is more uniform.
% @author: Andrea Tagliasacchi
% reformed by jjcao, using 1-ring to construct the connectivity graph
% @reform-data:     2009-9-3
 
if nargin < 1
    clear;clc;close all;
    filename = '../result/woman_contract_t(5)_nn(30)_WL(13.922768)_WH(1.000000)_sl(3.000000)_skeleton.mat';
    load(filename,'M');
    RADIUS = M.diameter*0.01;
    % visual debug conditions
    SHOW_RESULTS = true;
    SHOW_SAMPLING_PROGRESS = false;
    SHOW_EDGECOLLAPSE_PROGRESS = false;
else
    % visual debug conditions
    SHOW_RESULTS = false;
    SHOW_SAMPLING_PROGRESS = false;
    SHOW_EDGECOLLAPSE_PROGRESS = false;
end

if SHOW_SAMPLING_PROGRESS == true || SHOW_RESULTS == true
    close all;
    figure(1); movegui('northeast');
%     hg = getappdata( pcloud_view(M), 'hg' );
    mypoint3(M.cverts, '.r', 'markersize', 1);hold on;axis off; axis equal;set(gcf,'Renderer','OpenGL');
end
if SHOW_SAMPLING_PROGRESS
    figure(2);movegui('southeast');
%     hold on;axis off; axis equal;set(gcf,'Renderer','OpenGL');
end

%--- mark badly neighbored samples (their M.cverts/vset might is erroneous)
bad_sample = zeros( length(M.verts),1 );
for i=1:length(M.verts)
    if length(M.rings{i})==1
        bad_sample(i) = 1;
        disp(sprintf('has bad sample'));
    end
end

%--- FURTHEST POINT DOWNSAMPLE THE CLOUD
% use balls of size RADIUS to downsample the point cloud in a furthest sample fashion
%--- to be substituted by mean-shift downsampling, jjcao
kdtree = kdtree_build( M.cverts );
M.skelver = zeros( 0, 3 );
mindst = nan( length(M.cverts), 1 );
M.corresp = zeros( length(M.cverts), 1 );
for k=1:length(M.cverts)
    if M.corresp(k)~=0, continue, end;
        
    %--- query all the points for distances
    mindst(k) = inf; % make sure picked first
    
    %--- initialize the priority queue
    while ~all(M.corresp~=0)
        maxIdx = max_idx( mindst );
        if mindst(maxIdx) == 0
            break
        end

        % query its delta-neighborhood
[nIdxs, nDsts] = kdtree_ball_query( kdtree, M.cverts(maxIdx,:), RADIUS );%original
% [nIdxs, nDsts] = kdtree_ball_query( kdtree, M.cverts(maxIdx,:), M.radis(maxIdx) );
% [nIdxs, nDsts] = kdtree_ball_query( kdtree, M.cverts(maxIdx,:), min(M.radis(maxIdx),RADIUS) );

        % if its neighborhood has been marked already, skip ahead
        if all( M.corresp(nIdxs) ~= 0 )
            mindst(maxIdx) = 0; 
            continue;
        end;

        % create new node and update (closest) distances
        M.skelver(end+1,:) = M.cverts(maxIdx,:); %#ok<AGROW>
        for i=1:length(nIdxs)
            if mindst(nIdxs(i))>nDsts(i) || isnan(mindst(nIdxs(i)))
               mindst(nIdxs(i)) = nDsts(i);
               M.corresp(nIdxs(i)) = size(M.skelver,1);
            end
        end

        if SHOW_SAMPLING_PROGRESS == true
            figure(1); mypoint3( M.cverts(maxIdx,:), '*g');
            figure(2); scatter3( M.cverts(:,1),M.cverts(:,2),M.cverts(:,3), 5, mindst, 'filled');
        end
    end
end

%%--- COMPRESS MAHALANOBIS NEIGHBORHOOD MATRIX
% Neighbors of M.skelver is inherited from the skeletal samples to which they correspond
A = zeros( length(M.skelver), length(M.skelver) );
% surf_kdtree = kdtree_build( M.verts );
for pIdx=1:length(M.cverts)
    
    % skip badly conditioned points (projected to weird places as they have very few neighbors)
    if length(M.rings{pIdx})==1, continue; end
       
    %--- use k-nn, better
%     neighs = kdtree_k_nearest_neighbors( surf_kdtree, M.verts(pIdx,:), 10);
%     neighs = M.knn_idx(pIdx,:);
    neighs = M.rings{pIdx};
    
    % filter out bad samples again....
    neighs = neighs( bad_sample(neighs)==0 );
    
    pc = M.corresp(pIdx);
    if pc == 0, continue, end;
    for nIdx=1:length(neighs)
        nc = M.corresp(neighs(nIdx));
        if nc == 0, continue, end;
        
        A(pc,nc) = A(pc,nc) + 1;
        A(nc,pc) = A(nc,pc) + 1;
    end
end

%% deal with isolate points
isopts = zeros(1,0);
for i=1:size(A,1)
    if length( find( A(i,:)>0) ) == 1
        isopts(1, end+1) = i;
    end
end
if isempty(isopts)
    surf_kdtree = kdtree_build( M.skelver );
    for i=isopts
        neighs = kdtree_k_nearest_neighbors( surf_kdtree, M.skelver(i,:), 2)';
        for j = neighs
            A(i,j) = 1;
            A(j,i) = 1;
        end
    end
    kdtree_delete( surf_kdtree );
end
%% deal with close-by structure
% A( logical(eye(size(A)))) = 0;
% for i=1:size(A,1)
%     tmp = A(i,:);
%     if length(tmp(tmp>0))<5
%         A(i,tmp==1) = 0;
%     end
% end
% A(A<2) = 0;
A(A>0) = 1;

%% --- EDGE COLLAPSE 
% collapse the adjecency matrix A until the described graph is 1-dimensional
% this inherits some ideas from the Skeleton by Contraction paper.
while true
    %DEBUG: display connectivity and vertexes at every iteration
    if SHOW_EDGECOLLAPSE_PROGRESS
        hpts = mypoint3( M.skelver, '.r'); 
        heds = [];
        for i=1:size(A,1)
            for j=1:size(A,2)
                if( A(i,j)==1 )
                    heds(end+1) = myedge3(M.skelver(i,:), M.skelver(j,:)); %#ok<AGROW>
                end
            end
        end
        delete(hpts);
        delete(heds);
    end

    %--- RECOVER CONNECTIVITY
    % TODO: iterative update, HUGE SPEEDUP! if you don't reconstruct the
    % triangle count, but rather, you update it, it's MUCH MUCH faster
	%
    % recover the set of edges on triangles & count triangles
    tricount = 0;
    skeds = zeros(0,2);
    skcst = zeros(0,1);
    for i=1:length(M.skelver)
        neighs = sort( find(A(i,:)==1) );
        neighs = neighs( neighs>i );%touch every triangle only once
        for j=1:length(neighs)
            for k=j+1:length(neighs)
                if A(neighs(j),neighs(k)) == 1,
                    tricount = tricount+1;
                    skeds(end+1,:) = [i,neighs(j)];                                                        %#ok<AGROW>
                    skcst(end+1,:) = euclidean_distance( M.skelver(i,:), M.skelver(neighs(j),:) );         %#ok<AGROW>
                    skeds(end+1,:) = [neighs(j),neighs(k)];                                                %#ok<AGROW>
                    skcst(end+1,:) = euclidean_distance( M.skelver(neighs(j),:), M.skelver(neighs(k),:) ); %#ok<AGROW>
                    skeds(end+1,:) = [neighs(k),i];                                                        %#ok<AGROW>
                    skcst(end+1,:) = euclidean_distance( M.skelver(neighs(k),:), M.skelver(i,:) );         %#ok<AGROW>
                    % disp( skeds(end-2:end,:) );
                end
            end
        end
    end
    
    disp(sprintf('decimating skeletal graph, remaining #%d loops:', tricount));
    
    %--- STOP CONDITION
    % no more triangles? then the structure is 1D
    if tricount == 0, break, end;
    
    %--- DECIMATION STEP + UPDATES
    % collapse the edge with minimum cost, remove the second vertex
    [IGN, idx] = min( skcst );
    edge = skeds(idx,:);
    % update the location
    M.skelver( edge(1),: ) = mean( M.skelver( edge,: ) ); %#ok<AGROW>
    M.skelver( edge(2),: ) = NaN; %#ok<AGROW>
    % update the A matrix
    for k=1:size(A,1)
        if A(edge(2),k) == 1, 
            A(edge(1),k)=1; 
            A(k,edge(1))=1; 
        end
    end
    % remove the row
    A(edge(2),:) = 0;
    A(:,edge(2)) = 0;
    % update the correspondents
    M.corresp( M.corresp==edge(2) ) = edge(1); %#ok<AGROW>
end

% save the skeleton adjecency matrix
M.skel_adj = A;

% display extracted structure
if SHOW_RESULTS
    figure(2); movegui('southeast');
    mypoint3( M.skelver, '.r');
    for i=1:(size(A,1)-1)
        for j=(i+1):size(A,2)
            if( A(i,j)==1 )
               idx = [i;j];
               line(M.skelver(idx,1),M.skelver(idx,2),M.skelver(idx,3));
%                text(M.skelver(i,1),M.skelver(i,2),M.skelver(i,3),int2str(i));
            end
        end
    end
    axis off; axis equal; camorbit(0,0,'camera'); axis vis3d; view(0,90);view3d rot;
end

function maxIdx = max_idx(array)
[maxValue, maxIdx] = max(array);
function dist = euclidean_distance(p1, p2)
v=p1-p2;
dist = sqrt(dot(v,v));
