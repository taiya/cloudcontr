clear;clc;close all;
path(path,'../toolbox') ;

P1.points = read_off('new/fertility_1.2kv_01.off');
P2.points = read_off('new/fertility_1.2kv_05.off');
P3.points = read_off('new/fertility_1.2kv_15.off');
P4.points = read_off('new/fertility_1.2kv_20.off');
P5.points = read_off('new/output.off');

delta = .015;

T = makehgtform('yrotate',-thetas(1),          'xrotate',randn(1)*pi*delta, 'xrotate',randn(1)*pi*delta, 'xrotate',randn(1)*pi*delta, 'translate', delta*[randn(1,3)]);
P1.points = pcloud_affine_transform( P1, T );

T = makehgtform('yrotate',-thetas(5),          'xrotate',randn(1)*pi*delta, 'xrotate',randn(1)*pi*delta, 'xrotate',randn(1)*pi*delta, 'translate', delta*[randn(1,3)]);
P2.points = pcloud_affine_transform( P2, T );

T = makehgtform('yrotate',-thetas(10),          'xrotate',randn(1)*pi*delta, 'xrotate',randn(1)*pi*delta, 'xrotate',randn(1)*pi*delta, 'translate', delta*[randn(1,3)]);
P3.points = pcloud_affine_transform( P3, T );

T = makehgtform('yrotate',-thetas(15),          'xrotate',randn(1)*pi*delta, 'xrotate',randn(1)*pi*delta, 'xrotate',randn(1)*pi*delta, 'translate', delta*[randn(1,3)]);
P4.points = pcloud_affine_transform( P4, T );

% save fertility_multi.mat;
P.points = [P1.points; P2.points; P3.points; P4.points; P5.points;];

figure;set(gcf,'color','white');movegui('northwest');set(gcf,'Renderer','OpenGL');view3d rot;
scatter3(P.points(:,1),P.points(:,2),P.points(:,3),25,'.','MarkerEdgeColor', GS.PC_COLOR);hold on;
axis off; axis equal; camorbit(0,0,'camera'); axis vis3d; view(0,90);
write_pcloud_obj( 'P_r.obj',P.points,[],'andrea');