clear,clc;close all;
path('toolbox',path);
SHOW_FRONTS = false;
SHOW_CENTERS = false;
n = 100;
Base_name = 'E:\jjcao_lab\skeleton\classic\SkeleBlob\data\woman3\woman';

%% ------------ read skeleton nodes ------------
figure;set(gcf,'color','white');movegui('northwest');set(gcf,'Renderer','OpenGL');hold on;
view(90,-90);
off_file =[Base_name '.off'];
[M.verts,M.faces] = read_off(off_file);
if SHOW_FRONTS
    h = plot_mesh(M.verts, M.faces);
end
if SHOW_CENTERS
    h1 = scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),10,'.r');
end

M.skelver = [];
fronts=[];centers=[];skelnodes=[];
for step = 1:n
    tem = num2str(step);
    if step <=9 &&step >1
        Extra_name = ['_00' tem];
    elseif step >=10 && step <100
        Extra_name = ['_0' tem];
    elseif step >=100
        Extra_name = ['_' tem];
    else
        Extra_name = [];
    end
% ------------ read files ------------
    off_file =[Base_name Extra_name '.off'];
    frt_file = [Base_name Extra_name '.frt'];
    [M.verts,M.faces] = read_off(off_file);
    if isempty(M.verts)
        continue;
    end
    if SHOW_FRONTS
        delete(h);
        h = plot_mesh(M.verts, M.faces);
        for i = 1:length(fronts)
            delete(fronts{i});            
        end
    end
    if SHOW_CENTERS        
        if ~isempty(M.skelver)
            delete(h1);
            h1 = scatter3(M.skelver(:,1),M.skelver(:,2), M.skelver(:,3),600,'.b');
        end
    end    
    [frontIds, rigidity, color] = read_frt(frt_file);% read frt file
    fronts = cell(length(frontIds),1);
    for i = 1:length(centers)
        delete(centers{i});            
    end
    centers = cell(length(frontIds),1);
% ------------ compute the center of each front ------------
    for i = 1:length(frontIds)
        id = frontIds{i};
%         if ismember(1,id), warning('%d',i), end % index in frt file start from 0
        v = M.verts(id,:);
        center = sum(v,1)/length(id);
        if SHOW_FRONTS
            fronts{i} = scatter3(v(:,1),v(:,2), v(:,3),400,'.','MarkerEdgeColor',color);
        end
        if SHOW_CENTERS
            centers{i}=scatter3(center(:,1),center(:,2), center(:,3),700,'.','MarkerEdgeColor',color);
            axis off; axis equal; camorbit(0,0,'camera'); axis vis3d; view3d rot;
            drawnow expose update;
        end
        M.skelver = [M.skelver;center step rigidity];       
    end
end

M.level = M.skelver(:,4);
M.rigidity = M.skelver(:,5);
M.skelver = M.skelver(:,1:3);
save('centers.mat', 'M');
