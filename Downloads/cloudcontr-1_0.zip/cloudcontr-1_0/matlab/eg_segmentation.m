function [] = segmentation()
clear;clc;
% eg_segmentation
%%
sk_filename='../result/cylinder1_contract_t(4)_nn(14)_WL(3.438023)_WH(1.000000)_sl(3.000000)_skeleton_r.mat';
% sk_filename = 'horse_v1987_refined_contract_t(4)_nn(24)_WL(4.457578)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename = 'neptune_v11488_contract_t(4)_nn(30)_WL(10.718209)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='heptoroid_v14294_contract_t(4)_nn(30)_WL(11.955752)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='heptoroid_v14294_contract_t(4)_nn(30)_WL(11.955752)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='9HandleTorus_v2044_contract_t(5)_nn(25)_WL(4.521062)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='890_pegaso_12703_contract_t(4)_nn(30)_WL(11.270759)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='armadillo_v13840_contract_t(3)_nn(30)_WL(11.764353)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='armadillo_v502_contract_t(4)_nn(8)_WL(3.000000)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='dancer2_v11281_contract_t(4)_nn(30)_WL(10.621205)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='Dinopet_contract_t(3)_nn(30)_WL(6.257795)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='eagle_v9928_contract_t(4)_nn(30)_WL(9.963935)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='octopus_8476_contract_t(2)_nn(30)_WL(9.206519)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename='octopus_8476_contract_t(2)_nn(30)_WL(9.206519)_WH(1.000000)_sl(3.000000)_skeleton_r.mat';
% sk_filename='octopus_contract_t(2)_nn(30)_WL(13.016912)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='m324_v10002_contract_t(6)_nn(30)_WL(10.001000)_WH(1.000000)_sl(3.000000)_skeleton.mat';
%% consistent segmentation
% sk_filename ='horse1_contract_t(4)_nn(30)_WL(9.591142)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename='horse2_contract_t(4)_nn(30)_WL(9.591142)_WH(1.000000)_sl(3.000000)_skeleton_r.mat';
% sk_filename ='horse3_contract_t(4)_nn(30)_WL(9.591142)_WH(1.000000)_sl(3.000000)_skeleton_r.mat';
%% animation
% sk_filename ='cycle_01_contract_t(6)_nn(30)_WL(5.639149)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='cylinder_contract_t(4)_nn(14)_WL(3.438023)_WH(1.000000)_sl(3.000000)_skeleton_r.mat';
%%
% sk_filename ='mechpart_contract_t(6)_nn(23)_WL(4.358899)_WH(1.000000)_sl(3.000000)_skeleton.mat';
%  sk_filename ='796_raw_merge_contract_t(3)_nn(20)_WL(4.034848)_WH(1.000000)_sl(3.000000)_skeleton.mat';
% sk_filename ='simplejoint_v4770_contract_t(5)_nn(30)_WL(11.810318)_WH(1.000000)_sl(3.000000)_skeleton.mat';
%  sk_filename ='simplejoint_v4770_contract_t(5)_nn(30)_WL(11.810318)_WH(1.000000)_sl(3.000000)_skeleton_r.mat';
%%
global SHOW_FIND_BRANCH_PROGRESS;
SHOW_FIND_BRANCH_PROGRESS = true;
global M;
close all;
load(sk_filename,'M');
%% find joints first
global segments;
segments = zeros(size(M.skelver,1),1);%- for joints, + for branches, 0 for NaN.
segments(:) = NaN;
jidx = 0;
for i=1:length(segments)
    if ~isnan(segments(i)), continue, end;    
    
    if isnan(M.skelver(i,1))
        segments(i) = 0;
        continue;
    end
        
    edges = find( M.skel_adj(i,:)==1 );
    if length(edges) > 3 % joint
        jidx = jidx - 1;
        segments(i) = jidx;
    end
end
%% find branches
if SHOW_FIND_BRANCH_PROGRESS
figure; 
hold on; axis off;    axis equal;   set(gcf,'Renderer','OpenGL'); view3d rot;
end

bidx = 0;                     
idx = find(segments<0)';
if isempty(idx) %% without any joint
   M.branches = cell(1,1); 
   M.branches{1,1} = find(isnan(segments));
   segments(:) = 1;
else
    for i = idx
        edges = find( M.skel_adj( i,: )==1 );
        edges = edges( edges~=i );

        for j = edges 
            if isnan( segments(j) )
                bidx = bidx + 1;            
                find_branch(j, bidx);
            end        
        end
    end
    M.branches = cell(0,1);
    for i = 1:max(segments)
        M.branches{end+1,1} = find(segments==i);
    end
end
save(sk_filename, 'M');
%% segmentation
mins = abs(min(segments));
maxs = max(segments);
for i = 1 : mins
    segments(segments==-i) = maxs+i;
end
color = (1:(maxs+mins))';

color_all = zeros(M.nverts,1);
for i = 1:length(M.skelver)
    if segments(i)==0, continue, end;
    tmp = (M.corresp==i);    
    color_all(tmp,:) = segments(i);
end

figure;hold on;axis off; axis equal;set(gcf,'Renderer','OpenGL');view3d rot;set(gcf,'color','white')
scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),20,color_all);%,'filled'
for i=1:size(M.skel_adj,1)
    for j=1:size(M.skel_adj,2)
        if( M.skel_adj(i,j)==1 )
            myedge3(M.skelver(i,:), M.skelver(j,:), 'Color',[1 0 0], 'LineWidth', 2);
        end
    end
end

%% skeleton-shape mapping
% figure;hold on;axis off; axis equal;set(gcf,'Renderer','OpenGL');view3d rot;
% set(gcf,'color','white')
% for i = 1:size(M.skelver,1)
%     if isnan(M.skelver(i,1))
%         continue;
%     end    
%     vs = M.verts(M.corresp==i,:);
%     color = rand(1,3);
%     scatter3(vs(:,1),vs(:,2), vs(:,3), 10, repmat(color,size(vs,1),1),'filled');
% end
%%camorbit(0,0,'camera'); axis vis3d; view(0,0);%view3d rot;

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%ydzhao%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%branch=>joint%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure;hold on;axis off; axis equal;set(gcf,'Renderer','OpenGL');view3d rot;set(gcf,'color','white')
color_all_original =color_all;
for time =1:40%%��������
    empty = 0;
    for i = 1:maxs%%��ÿ��branch
        if(time == 1)
            branch = find( segments(:,1)==i );%%branch�ϵ�skel��
            kk = 1;
            for ii = 1:length(branch)
                for iii = 1:M.nverts
                    if(M.corresp(iii) == branch(ii,1))
                        branch_corr_cloud(1,kk) = iii;%%branch��Ӧ�ĵ���
                        kk = kk + 1;
                    end
                end
            end
            kk = 1;
            for j = 1:length(branch_corr_cloud)
                adj = M.rings{branch_corr_cloud(j)};%%���Ƶ��һ��
                for k = 1:length(adj)        	
                    bb = segments(M.corresp(adj(1,k)));%%һ����ɫ���branchһ����
                    if(bb > maxs)
                        boundary(1,kk) = branch_corr_cloud(j);%%�ҵ���branch�ı߽�
                        kk = kk + 1;
                        break;
                    end
                end %%find boundary of branch
            end
            boundary_current = boundary;
            clear boundary;
        else
            clear boundary_current;
            time
            dim = size(boundary_new,1);
            if(i > dim)
                break;
            end
                boundary_current = boundary_new(i,:);

        end
            kkk=1;
            aaaaaaaaa = size(boundary_current,2);
            for k = 1:size(boundary_current,2)
                ind = boundary_current(k);
                if(ind ~= 0)
                    adj = M.rings{ind};
                end
                for k = 1:length(adj)        	
                    %bb = segments(M.corresp(adj(1,k)));
                    color_cur = color_all(adj(1,k),:);
                    judge = 0;
                    for co = 1:maxs
                        if(color_cur == color(co,:))
                            judge = 1;
                            break;
                        end
                    end
                    if(judge == 0)
                        vs = M.verts(adj(1,k),:);  
                        c = color(i,:);
                        color_all(adj(1,k),:) = c;
                        boundary1(i,kkk) = adj(1,k);
                        empty = 1;
                        scatter3(vs(1,1),vs(1,2), vs(1,3), 10, repmat(c,size(vs,1),1));
                        kkk = kkk+1;                        
                    end
                end 
            end
    end
    if( empty == 0)
        break;
    end
    clear boundary_new;
    boundary_new = boundary1;
    clear boundary1;    
end
% for i = 1:M.nverts
%     vs = M.verts(i,:);
%     %c(i,:) = color_all(i,:)-color_all1(i,:);
%     c = color_all(i,:);
%     scatter3(vs(1,1),vs(1,2), vs(1,3), 10, repmat(c,size(vs,1),1));
% end
% num1 = find(c(:,1)~=0);
% num2 = find(c(:,2)~=0);
% num3 = find(c(:,3)~=0);
camorbit(0,0,'camera'); axis vis3d; view(0,0);%view3d rot;
b=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ydzhao%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [] = find_branch(j, bidx)
global segments;
global M;
global SHOW_FIND_BRANCH_PROGRESS;

if isnan( segments(j) )
    segments(j) = bidx;
    if SHOW_FIND_BRANCH_PROGRESS
        scatter3( M.skelver(j,1),M.skelver(j,2), M.skelver(j,3),15, bidx,'filled');
    end
    
    next = find( M.skel_adj(j,:)==1 );
    for i = next
        if isnan(segments(i))
        	next = i;
            break;
        end
    end
    find_branch(next,bidx);
end



