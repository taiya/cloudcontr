%%
clear;clc;close all;
path(path,'toolbox');

filename='../result/cylinder1_contract_t(4)_nn(14)_WL(3.438023)_WH(1.000000)_sl(3.000000)_skeleton_r_w.mat';
% filename='../result/horse2_contract_t(4)_nn(30)_WL(9.591142)_WH(1.000000)_sl(3.000000)_skeleton_r.mat';
% filename ='../result/simplejoint_v4770_contract_t(5)_nn(30)_WL(11.810318)_WH(1.000000)_sl(3.000000)_skeleton_r.mat';
load(filename,'M');
skelid = 1:size(M.skelver,1);
mstep = 9;
motions = zeros(mstep,length(skelid)*6+6);
tmp = length(skelid)*2-1;
for i=1:mstep
    for j=1:2:tmp
        motions(i,3*j+1:3*j+3)=[1.0,1.0,1.0];
    end
    motions(i, (end-2):end)=[1.5,1.5,1.5];
end
% save([filename(1:end-4), '_m.mat'], 'motions');
write_motion([filename(1:end-4), '_m.txt'], motions);