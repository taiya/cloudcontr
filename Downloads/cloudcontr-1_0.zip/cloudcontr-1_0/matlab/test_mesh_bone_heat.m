% test compution of bone heat
clear all;
clc;
path(path,'toolbox') 
% filename = '../data/cylinder1.off'; 
% skl_filename = '../data/cylinder1.skeleton'; 
filename = '../data/test_animation.off'; 
skl_filename = '../data/test_animation.skeleton'; 
%% initialize point cloud
close all;
DRAW_INITIALIZE = true;
DRAW_MINDIST = true;
M.filename = filename;
[M.verts,M.faces] = read_mesh(M.filename);
M.nverts = size(M.verts,1);
M.k_knn = Global_setting.compute_k_knn(M.nverts);
M.rings = compute_vertex_face_ring(M.faces);
[M.bbox, M.diameter] = Global_setting.compute_bbox(M.verts);
% [M.verts, M.toAdd, M.scale] = Global_setting.normalizeBoundingBox(M.verts, M.bbox, [0,0,0], 1);

%% initialize skeleton, assume that the first node is the root node.
[M.skelver, M.skel_adj, M.prev] = read_skeleton(skl_filename);
% [M.skelver] = Global_setting.normalizeSkeleton(M.skelver, M.toAdd, M.scale);
skelid = find( ~isnan(M.skelver(:,1)) )';% real skeleton nodes.

%% draw the result of initialization
if DRAW_INITIALIZE
    figure;set(gcf,'color','white');hold on;    
    scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),10,'b','filled');%,'filled'
    axis off;    axis equal;   set(gcf,'Renderer','OpenGL'); view3d rot;

    scatter3(M.skelver(:,1),M.skelver(:,2), M.skelver(:,3),10,'r','filled');%,'filled'
    for i=1:size(M.skel_adj,1)
        for j=1:size(M.skel_adj,2)
            if( M.skel_adj(i,j)==1 )
                myedge3(M.skelver(i,:), M.skelver(j,:), 'Color',[1 0 0], 'LineWidth', 2);
            end
        end
    end
end
%% compute nearest bone to each vertex. boneDists is OK!
boneDists = zeros(M.nverts, length(skelid)-1);
for i = 1:M.nverts
    pt = M.verts(i,:);
    for j = 2:length(skelid)
        boneDists(i,j-1) = Global_setting.distP2Seg(pt, M.skelver(skelid(j),:), M.skelver(M.prev(skelid(j)),:));%distance to segment
    end
end
% boneVis = [];
%% compute D, H, L. D is OK. H is OK when using boneVis.
options.rings = M.rings;
D = area_1_ring(M.verts,M.faces, M.rings)*2.0 + eps;
D = 1../D;
% D(:)=1; % D is very important for smoogher (longer) transition from one bone to other bones for non-uniform sampling.

closset = zeros(1, M.nverts);
H = zeros(1,M.nverts);
for i = 1:M.nverts
    [C,I] = min(boneDists(i,:));
    closset(i) = I(1);
    I = find(boneDists(i,:) <= C(1)*1.00001);
    for j = I
%         if boneVis(i,j)
            H(i) = H(i) + 1./(eps+boneDists(i,j)^2);
%         end
    end
end

% we need compute "(H-DL)w=HI" (with D=diag(1./area)), same as D(H/D-L)w=HI, i.e. DAw=HI
% so w=A^-1(HI/D)
L = compute_mesh_laplacian(M.verts,M.faces,'conformal',options);%combinatorial;conformal;%spring
for i = 1:M.nverts
    L(i,i) = L(i,i) + H(i)/D(i);
end
if DRAW_MINDIST
    figure;set(gcf,'color','white');hold on;   
    options.face_vertex_color = H';h2 = plot_mesh(M.verts, M.faces, options);colormap jet(256); colorbar('off');   
    axis off; axis equal; drawnow; hold on;set(gcf,'Renderer','OpenGL');view3d rot;
end
%% compute weights for each bone
figure;set(gcf,'color','white');hold on; 
for i=1:size(M.skel_adj,1)
    for j=1:size(M.skel_adj,2)
        if( M.skel_adj(i,j)==1 )
            myedge3(M.skelver(i,:), M.skelver(j,:), 'Color',[0 1 0], 'LineWidth', 2);
        end
    end
end
skelver = M.skelver(skelid,:);
attachment = zeros(M.nverts, length(skelid));
for j = 1:(length(skelid)-1)
    p = zeros(M.nverts,1.0);
    for i = 1:M.nverts
%         if boneVis(i,j) && boneDists(i,j) < boneDists(i,closset(i))*1.00001
        if boneDists(i,j) < boneDists(i,closset(i))*1.00001
            p(i) = H(i)/D(i);
        end        
    end
    
    tmp = L\p; 
    tmp(tmp>1.) = 1.;%clip just in case
    tmp(tmp<1e-8) = 0.;%clip just in case
    attachment(:,j) = tmp;
                    
    h1 = myedge3(M.skelver(j+1,:), M.skelver(M.prev(j+1),:), 'Color',[1 0 0], 'LineWidth', 6); hold on;
    options.face_vertex_color = attachment(:,j);h2 = plot_mesh(M.verts, M.faces, options);colormap jet(256); colorbar('off');   
    axis off; axis equal; drawnow; hold on;set(gcf,'Renderer','OpenGL');view3d rot;
    delete(h1);
    delete(h2);
end

%% normalization
tmp = sum(attachment,2);
attachment = attachment./repmat(tmp,1,size(attachment,2));
M.weights = attachment;
save([filename(1:end-4), '_w.mat'], 'M');
