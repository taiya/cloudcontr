clear;clc;close all;
% filename = '../result/cylinder1_contract_t(3)_nn(14)_WL(6.647095)_WH(1.000000)_sl(3.000000)_skeleton.mat';
filename ='../result/feline_v12465_contract_t(6)_nn(30)_WL(10.382775)_WH(1.000000)_sl(3.000000)_skeleton.mat';
load(filename,'M');

%% step 2: Point to curve �C by cluster ROSA2.0
tic
M.sample_radius = M.diameter*0.02;
% M = rosa_lineextract(M, C.verts, radius);
M = rosa_lineextract_andrea(M, M.cverts, M.sample_radius);
disp(sprintf('to curve:'));
toc
%% show results
figure;movegui('northeast');set(gcf,'color','white')
scatter3(M.verts(:,1),M.verts(:,2),M.verts(:,3),10,'.b');  axis off;axis equal;set(gcf,'Renderer','OpenGL');hold on;
scatter3(M.cverts(:,1),M.cverts(:,2),M.cverts(:,3),30,'.r'); axis off;axis equal;set(gcf,'Renderer','OpenGL');
camorbit(0,0,'camera'); axis vis3d; view(0,90);view3d rot;

figure; movegui('center');set(gcf,'color','white');
scatter3(M.verts(:,1),M.verts(:,2),M.verts(:,3),20,'.b');  hold on;
plot_skeleton(M, 600, 3);
axis off;axis equal;set(gcf,'Renderer','OpenGL');view(0,90);view3d rot;
%%
save([filename(1:(end-4)) '1.mat'],'M');