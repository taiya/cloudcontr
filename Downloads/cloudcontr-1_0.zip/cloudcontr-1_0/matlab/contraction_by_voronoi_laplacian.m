function [cverts, t, initWL, WC, sl] = contraction_by_voronoi_laplacian(M, options)
% point cloud contraction_by_voronoi_laplacian
% refer to Skeleton Extraction by Mesh Contraction 08
% mesh should be simplified by MeshLab/Filter/Clustering Decimation
% 
% inputs:
%   M.verts
%   M.faces
%   M.nverts
%   M.k_knn: k of knn
%   M.rings:
%   options.WL = 3;% ������˹����Ȩ,��ʼ
%   options.WC = 1;% ��ʼԼ��Ȩ
%   options.sl: scalar for increasing WL in each iteration
%   options.tc: Termination Conditions for total area ratio
%   options.iterate_time = 10;
%   options.b_update_rings����Ҫ��������ˣ�������ȡk����ͶӰ�ʷ�һ������ֵ���䲻�ȶ�
%
% outputs:
%   cverts: contracted vertices
%
% notes:
%   compute_point_laplacian() is slow. Not changing weights in iteration
%   and using combinatorial weights both lead to failed to contraction
%   enough.
%   Global_setting.one_ring_area() is slow.
% @author: deepfish, jjcao
% @create-data:     2009-4-10
% @modify-data:     2009-4-23
% @modify-data:     2009-5-19
% @modify-data:     2009-9-03
% profile on;

if nargin < 1
    clear;clc;close all;    
    M.filename = '../data/horse_v1987.off';
    options.USING_POINT_RING = GS.USING_POINT_RING;
    %options.WL = 1;
    %options.WC = 50;
    options.iterate_time = 10;
[M.verts,M.faces] = read_mesh(M.filename);
M.nverts = size(M.verts,1);
M.verts = GS.normalize(M.verts);
[M.bbox, M.diameter] = GS.compute_bbox(M.verts);

M.k_knn = GS.compute_k_knn(M.nverts);  
atria = nn_prepare(M.verts); 
[M.knn_idx, M.knn_dist] = nn_search(M.verts, atria, M.verts, M.k_knn); 
% ptrtree = BuildGLTree(M.verts);
% [M.knn_idx,M.knn_dist] = KNNSearch(M.verts, M.verts, ptrtree, M.k_knn);
% DeleteGLTree(ptrtree);
M.rings = compute_point_point_ring(M.verts,M.k_knn, M.knn_idx);
end

%##########################################################################
%% setting
%##########################################################################
% visual debug conditions
USE_MY_VORONOI = true;
KERNEL_SIZE = 10;
RING_SIZE_TYPE = 1;%1:min, 2:mean, 3:max
SHOW_CONTRACTION_PROGRESS = true;
Laplace_type = 'conformal';%conformal%combinatorial%spring%mvc

% setting
tc = getoptions(options, 'tc', GS.CONTRACT_TERMINATION_CONDITION); 
iterate_time = getoptions(options, 'iterate_time', GS.MAX_CONTRACT_NUM); 

initWL = getoptions(options, 'WL', GS.compute_init_laplacian_constraint_weight(M,Laplace_type)); %2.5932854821178033; % ������˹����Ȩ,��ʼ
if USE_MY_VORONOI
WC = getoptions(options, 'WC', 1) * M.nverts*5;% ��ʼԼ��Ȩ
else
    WC = getoptions(options, 'WC', 1) * M.nverts*0.05;
end
WH = ones(M.nverts, 1)*WC; % ��ʼԼ��Ȩ
sl = getoptions(options, 'sl', GS.LAPLACIAN_CONSTRAINT_SCALE); % scale factor for WL in each iteration! in original paper is 2;
WL = initWL;%*sl;

sprintf(['1) k of knn: %d\n 2) termination condition: %f \n 3)' ...
    'Init Contract weight: %f\n 4) Init handle weight: %f\n 5) Contract scalar: %f\n' ...
    '6) Max iter steps: %d'], M.k_knn, tc, initWL, WC, sl,iterate_time)

%% ������ʼ��
t = 1; % current iteration step
%% �������
tic
    if USE_MY_VORONOI
        h = (sum(sum(M.knn_dist(:, end-KERNEL_SIZE:end-1))) / KERNEL_SIZE / M.nverts) ^ 2;
        AW = MyVoronoiArea(M.verts, M.knn_idx, KERNEL_SIZE);
        G = Gnl_Eigen_Matrix(M.verts, h, AW);
    else        
        h = (sum(sum(M.knn_dist(:, end-KERNEL_SIZE:end-1))) / KERNEL_SIZE / M.nverts) ^ 2;         % Note if you want to compare the eigenvalue of two shapes, you need to set h the same for both shapes.
        AW = VoronoiArea(M.verts, M.knn_idx, sqrt(h));
        G = Gnl_Eigen_Matrix(M.verts, h, AW);
    end
disp(sprintf('voronoi 1:'));
toc
L = G*sparse(1 : M.nverts, 1 : M.nverts, AW);
A = [L.*WL;sparse(1:M.nverts,1:M.nverts, WH)];
%% �����ұ�
b = [zeros(M.nverts,3);sparse(1:M.nverts,1:M.nverts, WH)*M.verts];
tic
cverts = (A'*A)\(A'*b);
disp(sprintf('solve 1:'));
toc
% newVertices = A\b; % this is slow than above line

if SHOW_CONTRACTION_PROGRESS
    tic
    figure;axis off;    axis equal;   set(gcf,'Renderer','OpenGL'); view3d rot;hold on;
    camorbit(0,0,'camera'); axis vis3d; view(-90,0);    
    h1 = scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),10,'b','filled');
    h2 = scatter3(cverts(:,1),cverts(:,2), cverts(:,3),10,'r','filled');
    %legend('orignal points','contracted points');
    title(['iterate ',num2str(t),' time(s)'])    
    disp(sprintf('draw mesh:'));
    toc
end
%%
sizes = GS.one_ring_size(M.verts, M.rings, RING_SIZE_TYPE);   % min radius of 1-ring
size_new = GS.one_ring_size(cverts, M.rings, RING_SIZE_TYPE);
a(t) = sum(size_new)/sum(sizes);

while t<iterate_time %&& a(end) > tc
    tic 
    if USE_MY_VORONOI
        knn_dist = compute_knn_dist(cverts, M.knn_idx, M.k_knn); 
        h = (sum(sum(knn_dist(:, end-KERNEL_SIZE:end-1))) / KERNEL_SIZE / M.nverts) ^ 2;
        
        AW = MyVoronoiArea(cverts, M.knn_idx, KERNEL_SIZE);
        G = Gnl_Eigen_Matrix(cverts, h, AW);
    else
        atria = nn_prepare(cverts); 
        [knn_idx, knn_dist] = nn_search(cverts, atria, cverts, M.k_knn); 
        h = (sum(sum(knn_dist(:, end-KERNEL_SIZE:end-1))) / KERNEL_SIZE / M.nverts) ^ 2;
        AW = VoronoiArea(cverts, knn_idx, sqrt(h));
        G = Gnl_Eigen_Matrix(cverts, h, AW);
    end

    disp(sprintf('voronoi %d:',t));
    toc
    L = G*sparse(1 : M.nverts, 1 : M.nverts, AW);
    
    WL = sl*WL;    
    if WL>GS.MAX_LAPLACIAN_CONSTRAINT_WEIGHT,WL=GS.MAX_LAPLACIAN_CONSTRAINT_WEIGHT;end; % from Oscar08's implementation, 2048
    if options.USING_POINT_RING
        WH = WC.*(sizes./size_new);
    else    
%         WH = WC.*(sizes./size_new);
%         WH = WC.*((sizes./size_new).^0.5); % a little diff with Oscar08
        WH = WC*(ratio_new.^(-0.5));% from Oscar08, if the size is area
    end
    WH(WH>GS.MAX_POSITION_CONSTRAINT_WEIGHT) = GS.MAX_POSITION_CONSTRAINT_WEIGHT;% from Oscar08's implementation, 10000
    
    A = real([WL*L;sparse(1:M.nverts,1:M.nverts, WH)]);
    
    % ���·����ұ�
    b(M.nverts+1:end, :) = sparse(1:M.nverts,1:M.nverts, WH)*cverts;
    
    tic
    tmp = (A'*A)\(A'*b);
    disp(sprintf('solve %d:',t));
    toc
   
    size_new = GS.one_ring_size(tmp, M.rings, RING_SIZE_TYPE);  
    a(end+1) = sum(size_new)/sum(sizes);
    
    tmpbox = GS.compute_bbox(tmp);
%     if sum( (tmpbox(4:6)-tmpbox(1:3))> ((M.bbox(4:6)-M.bbox(1:3))*1.2) ) > 0
%         break;
%     end
%     if a(t)-a(end)<tc
%         break;
%     else 
        cverts = tmp;
%     end
    
    t = t+1
    
    if SHOW_CONTRACTION_PROGRESS
        % ��ʾǰ�����     
        delete(h1);delete(h2);
        h1 = scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),10,WH,'filled');
        h2 = scatter3(cverts(:,1),cverts(:,2), cverts(:,3),10,ones(M.nverts,1)*WL,'filled');
        %legend('orignal points','contracted points');
        title(['iterate ',num2str(t),' time(s)']);   drawnow;     
    end
end
clear tmp;

figure;
plot(a);
if t<iterate_time
    if a(end) < tc 
        sprintf('exist iteration for termination condition meets!')
    else
         warning('exist iteration unnormally!');
    end
end
% profile off;
% profile viewer;

%%
default_filename = sprintf('result\\%s_contract_t(%d)_nn(%d)_WL(%f)_WH(%f)_sl(%f).off',...
    M.filename(1:end-4), t, M.k_knn, initWL, WC, sl);
[FileName,PathName,FilterIndex] = uiputfile( {'*.off';'*.obj';'*.wrl';'*.*'}, 'Save as',default_filename);
if FilterIndex~=0
    write_mesh([PathName FileName],cverts, M.faces);
end

function [knn_dist] = compute_knn_dist(verts, knn_idx, k_knn)
knn_dist = zeros(size(verts,1), k_knn);
for i = 1:length(knn_idx)
    pts = verts(knn_idx(i),:);
    s = (pts(:, 1)-verts(i, 1)).^2 + (pts(:, 2) - verts(i, 2)) .^ 2 + (pts(:, 3) - verts(i, 3)) .^ 2;
    knn_dist(i,:) = sqrt(s)';
end