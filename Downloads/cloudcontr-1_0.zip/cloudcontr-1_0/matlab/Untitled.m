%% mesh off and obj and point obj 2 pcloud off
clear;clc;close all;
path(path,'toolbox');
[M.verts, M.faces, M.normals] = read_mesh('../data/woman.off');
% [M.normals] = compute_vertex_normal(M.verts,M.faces, true);
% M.verts = GS.normalize(M.verts);
% figure;axis off;    axis equal;   set(gcf,'Renderer','OpenGL'); view3d rot;hold on;set(gcf,'color','white');
% scatter3(M.verts(:,1),M.verts(:,2), M.verts(:,3),20,'g','filled');
% camorbit(0,0,'camera'); axis vis3d; view(-90,0);  
write_mesh('../result/woman_11690.off', M.verts,[],M.normals);
% write_off('../result/fertility_1n.pwn', M.verts,[],[]); % point off 2 MPU's pwn
% write_point_obj([filename(1:(end-3)) 'obj'], M.verts);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% pcloud off 2 Andrea's pcloud obj
clear;clc;close all;
path(path,'toolbox');
[M.verts, M.faces, M.normals] = read_mesh('../data/woman_7164.off');
[M.normals] = compute_vertex_normal(M.verts,M.faces, true);
M.verts = GS.normalize(M.verts);
write_off('../result/woman_7164.xyz', M.verts,M.faces,M.normals);
%write_pcloud_obj('../result/fertility_2n.obj', M.verts,M.normals,'andrea');

%% draw pcloud and contracted pcloud
filename = '../data/horse_v11912.off';
sk_filename='../result/pipeline/horse_v11912_contract_t(3)_nn(30)_WL(12.505353)_WH(1.000000)_sl(3.000000).off';
[M.verts,M.faces] = read_mesh(filename);
M.verts = GS.normalize(M.verts);
[M.cverts,M.faces] = read_mesh(sk_filename);
%% draw contraction
figure;set(gcf,'color','white');movegui('northwest');set(gcf,'Renderer','OpenGL');view3d rot;
% idx = 4248;
% sidx = 111;
scatter3(M.verts(:,1),M.verts(:,2),M.verts(:,3),22,'.','MarkerEdgeColor', GS.PC_COLOR);hold on;
% scatter3(M.verts(idx,1),M.verts(idx,2),M.verts(idx,3),80,'.r');hold on;
% scatter3(M.skelver(sidx,1),M.skelver(sidx,2),M.skelver(sidx,3),80,'.r');hold on;
% scatter3(M.skelver(:,1),M.skelver(:,2),M.skelver(:,3),60,'.g');hold on;
scatter3(cverts(:,1),cverts(:,2), cverts(:,3),25,'.r');
% scatter3(M.cverts(:,1),M.cverts(:,2),M.cverts(:,3),20,'.r');
% scatter3(C.verts(:,1),C.verts(:,2),C.verts(:,3),20,'.r');
axis off; axis equal; camorbit(0,0,'camera'); axis vis3d; view(-90,0);

GS.plot_knn_graph(M.verts, M.knn_idx, 'LineWidth', 2,'Color','r');
% GS.plot_ring_graph(M.verts, M.rings, 'LineWidth', 2,'Color','r');
view3d rot;axis off; axis equal; camorbit(0,0,'camera'); axis vis3d; view(90,0);
% GS.plot_connectivity(M.skelver, A);
%% save contracted poinst
default_filename = sprintf(['%s_contract_t(%d)_nn(%d)_WL(%f)_WH(%f)_sl(%f).' 'off'],...
    M.filename(1:end-4), t, M.k_knn, initWL, WC, sl);
[FileName,PathName,FilterIndex] = uiputfile( {'*.off';'*.obj';'*.wrl';'*.*'}, 'Save as',default_filename);
if FilterIndex~=0
    write_mesh([PathName FileName],cverts, M.faces,[]);
end
%% draw result
sk_filename='../result/woman_contract_t(5)_nn(14)_WL(14.439483)_WH(1.000000)_sl(3.000000)_skeleton.mat';
load(sk_filename,'M');
figure;set(gcf,'color','white');movegui('northwest');set(gcf,'Renderer','OpenGL');view3d rot;
scatter3(M.verts(:,1),M.verts(:,2),M.verts(:,3),50,'.','MarkerEdgeColor', GS.PC_COLOR);hold on;
plot_skeleton(M);
axis off; axis equal; camorbit(0,0,'camera'); axis vis3d; view(0,90);
%%
%M.skel_adj=A;
figure;set(gcf,'color','white');movegui('northwest');set(gcf,'Renderer','OpenGL');view3d rot;
plot_skeleton(M);
axis off; axis equal; camorbit(0,0,'camera'); axis vis3d; view(0,90);
[M, graph] = build_graph(M);
% write_cg();
fid = fopen([M.filename(1:end-4), '.cg'],'w');
if( fid~=-1 )
    fprintf(fid, '# D:3 NV:%d NE:%d\n', size(M.skelver,1), size(graph,1));
    fprintf(fid, 'v %f %f %f\n', M.skelver');
    fprintf(fid, 'e %d %d\n', graph');
    fclose(fid);
end

% write_mapping();
fid = fopen([M.filename(1:end-4), '.map'],'w');
if( fid~=-1 )
    fprintf(fid, '%d\n', M.corresp);
    fclose(fid);
end
save([M.filename(1:end-4), '_r.mat'], 'M');

%%
tmp = zeros(length(M.rings),1);
for i=1:length(M.rings)
    tmp(i) = length(M.rings{i});    
end

B=A;
A(A<2) = 0;
A(A>0) = 1;
tmp = zeros(size(A,1),1);
for i=1:size(A,1)
    row = A(i,:);
    row = row(row>0);
    row = row(row < 2);
    tmp(i) = length(row);
end

%% downsampling
filename = '../data/woman';
extension='.off';
P.filename = [filename extension];
[P.points,P.faces,P.normals] = read_mesh(P.filename);
P.points = GS.normalize(P.points);

P_out = pcloud_downsample( P, 0.01 );
write_off('../result/woman.off', P_out.points,[],P_out.normals);