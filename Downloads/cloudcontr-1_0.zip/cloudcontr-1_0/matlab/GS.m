classdef GS
    %GLOBAL_SETTING Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (Constant)
        USING_POINT_RING = true; % false for Oscar, ture for our implementation
        MIN_NEIGHBOR_NUM = 8;
        MAX_NEIGHBOR_NUM = 30;% orginal 30
        LAPLACIAN_CONSTRAINT_WEIGHT = 3; % init Laplacian contraction weight, compute automatically now.
        POSITION_CONSTRAINT_WEIGHT = 1; % init position constraint weight
        LAPLACIAN_CONSTRAINT_SCALE = 3; % scalar for increasing WL in each iteration
        MAX_LAPLACIAN_CONSTRAINT_WEIGHT = 2048;%2048
        MAX_POSITION_CONSTRAINT_WEIGHT = 10000;%10000
        MAX_CONTRACT_NUM = 30; % max contract iterations 30
        CONTRACT_TERMINATION_CONDITION = 0.01;% contract Termination Conditions for total area ratio 0.01  
%         PC_COLOR = {1, .73, .0, 0.5f}; // gold
%         PC_COLOR = {0.275, .337, .60, 0.5f}; // blue
        PC_COLOR = [1.0, .65, .35]; % point cloud color, orange
%         E_PCA = 0.8;
%         MAX_MLS_NUM = 10;
%         MLS_TERMINATION_CONDITION = 0.8; % MLS Termination Conditions for total area ratio
    end    
    
    methods (Static)
        function [verts] = normalize(verts)
            % scale to unitBox and move to origin
            bbox = [min(verts(:,1)), min(verts(:,2)), min(verts(:,3)), max(verts(:,1)), max(verts(:,2)), max(verts(:,3))];
            c = (bbox(4:6)+bbox(1:3))*0.5;            
            verts = verts - repmat(c, size(verts,1), 1);
            s = 1.6 / max(bbox(4:6)-bbox(1:3));% make the bbox's diagnol = 1.6. %1.0, 1.6
            verts = verts*s;
        end
        function [] = test_normalize(verts)
            verts = GS.normalize(verts);
            [bbox, diameter] = GS.compute_bbox(verts);
            tmp = max(bbox(4:6)-bbox(1:3));
            if abs(tmp-1.0) > eps
                warning('GS.normalize() is wrong! the bounding box diagonal is: "%s" ', tmp);
            end
        end
        function verts = normalizeSkeleton(verts, toAdd, scale)
            verts = verts*scale + repmat(toAdd, size(verts,1), 1);
        end
        function [bbox, diameter] = compute_bbox(verts)
            bbox = [min(verts(:,1)), min(verts(:,2)), min(verts(:,3)), max(verts(:,1)), max(verts(:,2)), max(verts(:,3))];
            rs = bbox(4:6)-bbox(1:3);
            diameter = sqrt(dot(rs,rs));
        end
        function r = is_in_bbox(vert, bbox)
            r = [vert, vert] - bbox;
            if sum(r(1:3)>=0) == 3 && sum(r(4:6)<=0) == 3
                r = 1;
            else
                r = 0;
            end
        end
        function ms = one_ring_size(verts,rings,type)
            n = size(verts,1);
            ms = zeros(n,1);
            switch type
                case 1
                    parfor i = 1:n
                        ring = rings{i};    
                        tmp = repmat(verts(i,:), length(ring),1) - verts(ring,:);
                        ms(i) = min( sum(tmp.^2,2).^0.5);
                    end
                case 2
                    parfor i = 1:n
                        ring = rings{i};    
                        tmp = repmat(verts(i,:), length(ring),1) - verts(ring,:);
                        ms(i) = mean( sum(tmp.^2,2).^0.5);
                    end                    
                case 3
                    parfor i = 1:n
                        ring = rings{i};    
                        tmp = repmat(verts(i,:), length(ring),1) - verts(ring,:);
                        ms(i) = max( sum(tmp.^2,2).^0.5);
                    end                    
            end
        end       
        function wl = compute_init_laplacian_constraint_weight(M,type)
            switch lower(type)
                case 'distance'
                    warning('not implemented!'); 
                case 'spring'
                    warning('not implemented!');                  
                case {'conformal','dcp'} % conformal laplacian  
                    if GS.USING_POINT_RING
                        ms = GS.one_ring_size(M.verts,M.rings,2);
                        wl = 1.0/(5.0*mean(ms));
%                     wl = max(3, 0.1*(nverts)^0.5); % original guess of JJCAO                        
                    else                        
                        wl = 1.0/(10.0*sqrt(GS.average_face_area(M.verts,M.faces))); % implementation of Oscar08    
                    end
                otherwise % combinatorial or mvc
                    if GS.USING_POINT_RING
                        ms = GS.one_ring_size(M.verts,M.rings,2);
                        wl = 1.0/(5.0*mean(ms));
%                     wl = max(3, 0.1*(nverts)^0.5); % original guess of JJCAO                        
                    else                        
                        wl = 1.0/(10.0*sqrt(GS.average_face_area(M.verts,M.faces))); % implementation of Oscar08    
                    end
            end
        end
        function num = compute_k_knn(nverts)
            num = max(GS.MIN_NEIGHBOR_NUM,round(nverts*0.012));
            if num > GS.MAX_NEIGHBOR_NUM
                num = GS.MAX_NEIGHBOR_NUM;
            end
        end
        function afa = average_face_area(verts, faces)
            afa = 0.0;
            n = size(faces,1);
            for i = 1:n
                vi = verts(faces(i,1),:);
                vj = verts(faces(i,2),:);
                vk = verts(faces(i,3),:);
                afa = afa + 0.5 * norm(cross(vi-vk,vi-vj));
            end   
            afa = afa/n;
        end
        function areas = one_ring_area(verts,rings)
        % too slow, use one_ring_size() instead
            n = size(verts,1);
            areas = zeros(n,1);
            for i = 1:n
                ring = rings{i};    
                tmp = length(ring)-1;
                for ii = 1: tmp
                    j = ring(ii); k = ring(ii+1);
                    vi = verts(i,:);
                    vj = verts(j,:);
                    vk = verts(k,:);
%                     areas(i) = areas(i) + triangle_area([vi;vj;vk]);
                    areas(i) = areas(i) + 0.5 * norm(cross(vi-vk,vi-vj));
                end
            end
        end                  
        function dist = distP2Seg(p, s1, s2)
            % distance from a point p to a segment composed by two points:
            % s1 and s2.
            us21 = (s2-s1)./norm(s2-s1);
            dist = (p-s1)*us21';
            if dist > 0 && dist < norm(s2-s1)
                tmp = s1+us21.*dist;
                dist = norm(p-tmp);
            else
                dist = min( norm(p-s1), norm(p-s2));
            end
        end       
        function pcas = compute_pca(verts, rings)
            nverts = size(verts,1);
            pcas = zeros(nverts,1);
            for i = 1:nverts    
                points = verts( rings{i},:);
                [Y,xy,v] = pca(points',3);
                if sum(v) == 0
                    pcas(i) = 0;
                else
                    pcas(i) = v(1)/sum(v);
                end
            end
        end
        %%% plot
        function [] = plot_ring_graph(verts, rings, varargin)
            % GS.plot_ring_graph(M.verts, M.rings, 'LineWidth', sizee,'Color','r');
            for i=1:size(verts,1)
                idx = rings{i};
                %line( verts(idx,1),verts(idx,2),verts(idx,3), varargin{:} );
                line( verts(idx,1),verts(idx,2),verts(idx,3), 'LineWidth', 2,'Color','r');
            end
        end
        function [] = plot_knn_graph(verts, knn_idx, varargin )
            %GS.plot_knn_graph(M.verts, M.knn_idx, 'LineWidth', sizee,'Color','r');
            for i=1:size(verts,1)
                idx = knn_idx(i,:);
                line( verts(idx,1),verts(idx,2),verts(idx,3), varargin{:} );
            end
        end
        
        function [] = plot_connectivity(verts, A)
            A( logical(eye(size(A)))) = 0;
            tmax = max(max(A))*1.0;
            for i=1:(size(A,1)-1)
                for j=(i+1):size(A,2)
                    if( A(i,j)>0 )
                        idx = [i;j];
                       line( verts(idx,1),verts(idx,2),verts(idx,3), 'LineWidth', 150*A(i,j)/tmax, 'Color', [A(i,j)/tmax,.0,.0]);
%                        text(verts(i,1),verts(i,2),verts(i,3),int2str(i)) ;
                    end
                end
            end
            %axis off; axis equal; camorbit(0,0,'camera'); axis vis3d; view(0,90);view3d rot;
%             hold on;
%             i = 302;%285,302
%             h = scatter3(verts(i,1),verts(i,2),verts(i,3),40,'.r');
        end
    end    
end
