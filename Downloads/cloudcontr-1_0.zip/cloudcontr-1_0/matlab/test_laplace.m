clear;close all;

filename = '../data/cylinder1.off';
options.USING_POINT_RING = false;

[M.verts,M.faces] = read_mesh(filename);
M.nverts = size(M.verts,1);
M.verts = GS.normalize(M.verts);

%% test mesh laplacian using vertex_face_ring, OK
M.frings = compute_vertex_face_ring(M.faces);
M.rings = compute_vertex_ring(M.faces, M.frings);
%% draw
figure;axis off;    axis equal;   set(gcf,'Renderer','OpenGL'); view3d rot;hold on;set(gcf,'color','white');
camorbit(0,0,'camera'); axis vis3d; view(-90,0);    
options.face_vertex_color = M.verts(:,3);
h1 = plot_mesh(M.verts, M.faces, options);colorbar('off');

i = 3860;
h2 = scatter3(M.verts(i,1),M.verts(i,2), M.verts(i,3),20,'r','filled');
h3 = scatter3(M.verts(M.rings{i},1),M.verts(M.rings{i},2), M.verts(M.rings{i},3),20,'g','filled');
m = 1;
for j = M.rings{i}
    tmp = M.verts(j,:);
    str = sprintf('%d',m);
    text(tmp(1),tmp(2),tmp(3),str,'FontSize',18);
    m = m+1;
end
% for j = M.frings{i}
%     tmp = M.verts(M.faces(j,:),:);
%     tmp = mean(tmp,1);
%     str = sprintf('%d',j);
%     text(tmp(1),tmp(2),tmp(3),str);
% end

%%
Laplace_type = 'conformal';
L = -compute_mesh_laplacian(M.verts,M.faces,Laplace_type,options);

