Extraction curver skeleton from mesh and point cloud modle.

the entrance: 
1. eg_skeleton_laplacian_rosa.m: extract a skeleton
2. refine_skeleton.m: refine a skeleton. Most of times, it is not necessary.  And there are some switches for different type of refinement.

Main files:
	GS.m: global setting and some assistant funcitons
	contraction_by_mesh_laplacian.m: laplacian contraction
	rosa_lineextract.m: topoligical thinning

Main references:
1. Junjie Cao, Andrea Tagliasacchi, Matt Olson, Hao Zhang, and Zhixun Su, "Point Cloud Skeletons via Laplacian-Based Contraction," Proc. of IEEE Shape Modeling International, 187-197, 2010.
2. O. K.-C. Au, C.-L. Tai, H.-K. Chu, D. Cohen-Or, and T.-Y. Lee, ��Skeleton extraction by mesh contraction,�� ACM Trans. Graphics, vol. 27, no. 3, pp. 44:1�C44:10, 2008